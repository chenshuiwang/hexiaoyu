
let audioBgStop = "https://img.qlchat.com/qlLive/activity/image/MRBYOO25-CJR6-AQGZ-1583224359908-D23JZJQ97MB4.png";
let audioBgPlay = "https://img.qlchat.com/qlLive/activity/image/RFBLQ3VA-8YLS-S3PP-1583224365636-6RJ2D4PZAHIV.png";

export default class TitlePlayer{
    init({ url, bgPanel, position, callback, isAutoPlay }) {
        if (this.trumpet) {
            this.trumpet.destroy();
        }
        if (!bgPanel) {
            return;
        }
        this.callback = callback;
        
        this.trumpet = new Laya.Image();
        this.trumpet.width = 63;
            this.trumpet.height = 46;
        if(!position){
            this.trumpet.left = 50;
            this.trumpet.bottom = 40;
        }else{
            this.trumpet.left = position.left;
            this.trumpet.bottom = position.bottom;
        }
        if(this.callback === undefined){
            this.handleEnded();
        }
        //this.handleEnded();
        
        bgPanel.addChild(this.trumpet);
        // this.trumpet.loadImage(audioBgStop);
        this.url = url;

        this.trumpet.on(Laya.Event.CLICK, this, this.playTitleSound);
        if (isAutoPlay !== false) {
            console.log('AutoPlay');
            this.playTitleSound();
        }

        if(window.needAppPlayer) {
            if(!window.gameSoundEndedArr) {
                window.gameSoundEndedArr = [];
            }
            window.gameSoundEndedArr.push(this.handleStop.bind(this));
        }
    }

    handleStop(){
        this.isPlaying = false;
        this.audioAni&&Laya.timer.clear(this, this.audioAni);
        this.trumpet.skin = audioBgStop;
    }
   
    handleEnded(){
        if(this.callback && this.isAutoEnded){
            this.callback()
        }
        this.isPlaying = false;
        this.audioAni&&Laya.timer.clear(this, this.audioAni);
        this.trumpet.skin = audioBgStop;
    }

    // 播放题目声音
    playTitleSound(e) {
        this.isAutoEnded=false;
        Laya.SoundManager.stopAllSound();
        // 允许重复播放
        if (this.isPlaying) {
            Laya.SoundManager.stopSound(this.url);
            this.audioAni&&Laya.timer.clear(this, this.audioAni);
        }
        this.isPlaying = true;
        this.trumpet.skin = audioBgPlay;
        // 如果全局挂载了播放方法，调用全局的方法， 否则调用Laya soundManager播放
        if(window.playSound && window.needAppPlayer) {
            this.soundPlay = window.playSound(this.url, this.handleEnded.bind(this)); 
        } else {
            this.soundPlay = Laya.SoundManager.playSound(this.url, 1, new Laya.Handler(this, this.handleEnded));
        }
        this.isAutoEnded=true;


        // 音频动画
        this.audioAni = (e) => {
            if (this.trumpet.skin== audioBgStop) {
                this.trumpet.skin = audioBgPlay;
            } else {
                this.trumpet.skin = audioBgStop;
            }
        }
        Laya.timer.frameLoop(20, this, this.audioAni);
    }
   

    remove() {
        this.trumpet.destroy();
    }
}

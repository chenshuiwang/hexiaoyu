
export default class AudioPlayer {
    constructor(url, target, position, isAutoPlay=true, callback=null) {
        this.url = url;
        this.trumpet = target;
        this.position = position;
        this.isAutoPlay = isAutoPlay;
        this.callback = callback;
        console.log(target)
        // if (this.trumpet) {
        //     this.trumpet.destroy();
        // }
        if (!target) {
            return;
        }
        
        // this.trumpet = new Laya.Image();
        // this.trumpet.width = 63;
        // this.trumpet.height = 46;
        // if(!position){
        //     this.trumpet.left = 50;
        //     this.trumpet.bottom = 40;
        // }else{
        //     this.trumpet.left = position.left;
        //     this.trumpet.bottom = position.bottom;
        // }
        if(this.callback === null){
            this.handleEnded();
        } else {
            // this.trumpet.skin = audioBgStop;
        }
        //this.handleEnded();
        
        // bgPanel.addChild(this.trumpet);
        // this.trumpet.loadImage(audioBgStop);

        this.trumpet.on(Laya.Event.CLICK, this, this.playTitleSound);
        if (isAutoPlay !== false) {
            console.log('AutoPlay');
            this.playTitleSound();
        }

        if(window.needAppPlayer) {
            if(!window.gameSoundEndedArr) {
                window.gameSoundEndedArr = [];
            }
            window.gameSoundEndedArr.push(this.handleStop.bind(this));
        }
    }

    handleStop(){
        this.isPlaying = false;
        // this.audioAni && Laya.timer.clear(this, this.audioAni);
        this.aniplay();
    }
   
    handleEnded(){
        if(this.callback && this.isAutoEnded){
            this.callback()
        }
        this.isPlaying = false;
        this.aniStop();
        //this.audioAni && Laya.timer.clear(this, this.audioAni);
        // this.trumpet.skin = audioBgStop;
    }

    changUrl(url) {
        this.url = url;
    }

    // 播放题目声音
    playTitleSound(url) {
        this.isAutoEnded=false;
        Laya.SoundManager.stopAllSound();
        if (typeof url === 'string') {
            this.url = url;
        }
        // 允许重复播放
        if (this.isPlaying) {
            Laya.SoundManager.stopSound(this.url);
            // this.audioAni&&Laya.timer.clear(this, this.audioAni);
            this.aniStop();
        }
        this.isPlaying = true;
        // this.trumpet.skin = audioBgPlay;
        this.aniplay();
        if(window.playSound && window.needAppPlayer) {
            this.soundPlay = window.playSound(this.url, this.handleEnded.bind(this)); 
        } else {
            this.soundPlay = Laya.SoundManager.playSound(this.url, 1, new Laya.Handler(this, this.handleEnded));
        }
        this.isAutoEnded=true;

        // 音频动画
        // this.audioAni = (e) => {
        //     if (this.trumpet.skin== audioBgStop) {
        //         this.trumpet.skin = audioBgPlay;
        //     } else {
        //         this.trumpet.skin = audioBgStop;
        //     }
        // }
        // Laya.timer.frameLoop(20, this, this.audioAni);
    }

    aniplay() {
        this.trumpet._children[0].visible = true;
        this.trumpet._children[0].play(0, true);
        this.trumpet._children[1].visible = false;
    }

    aniStop() {
        this.trumpet._children[0].visible = false;
        this.trumpet._children[1].visible = true;
    }

    remove() {
        this.trumpet.destroy();
    }
}

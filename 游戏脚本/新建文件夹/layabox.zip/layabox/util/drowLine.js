let apache_1 = "https://img.qlchat.com/qlLive/activity/image/R6S363ZC-I92C-9OPH-1583208333399-AJJVOYQQ7TS4.png";
export default function drawLine({ box_one, box_two, scenes, views, callback }) {
    // console.log("box_one:",box_one, box_two)
    if (!scenes._spArr) {
        scenes._spArr = [];
    }
    let bgWrapper = new Laya.Box()
    let _sp = new Laya.Sprite();
    
    scenes._spArr.push(bgWrapper);

    // 计算坐标
    let x1 = box_one.x + box_one.width / 2;
    let y1 = box_one.y + box_one.height + 5;
    let x2 = box_two.x + box_two.width / 2;
    let y2 = box_two.y -5;
    let x = x1;
    let y = y1;
    let l = 0;
    
    // 计算连线长度
    let lineLenght = (Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2))).toFixed(0) - 10;
    // 计算角度
    let lineRota = Math.atan((x2 - x1) / (y1 - y2)) / Math.PI * 180
    
    // 连线动画
    let dx = lineLenght / 20;
    let animate = (e) => {
        l = l + dx;
        if (l >= lineLenght) {
            l == lineLenght
            Laya.timer.clear(this, animate);
        }
        
        _sp.graphics.fillTexture(Laya.loader.getRes(apache_1), 0, 0, 10, l);
    }

    // 纹理图片加载完毕开始画图
    Laya.loader.load(apache_1, Laya.Handler.create(this, () => {
        bgWrapper.x = x1
        bgWrapper.y = y1;
        _sp.pivot(0,0)
        _sp.rotation = lineRota;
        
        // _sp.graphics.scale(0.5,1);
        // _sp.graphics.fillTexture(Laya.loader.getRes(apache_1), 0, 0, 1, l);

        bgWrapper.addChild(_sp)
        views.addChild(bgWrapper);
        Laya.timer.frameLoop(1, this, animate);
    }));
    callback && callback();
}
let GlowFilter = Laya.GlowFilter

// 选中效果
export function addSelect( item, callback ) {
    // 边框样式
    if (!item.boxBorder) {
        item.boxBorder = new Laya.Sprite();
        let boxW = item.width;
        let boxH = item.height;
        let boxR = 30;
        var path =  [
            ["moveTo", boxR, 0], 
            ["arcTo", boxW, 0, boxW, boxR, boxR], 
            ["arcTo", boxW, boxH, boxW-boxR, boxH, boxR],
            ["arcTo", 0, boxH, 0, boxH-boxR, boxR], 
            ["arcTo", 0, 0, boxR, 0, boxR],
        ];
        item.boxBorder.graphics.drawPath(0, 0, path, { fillStyle: "#fff" }, { "strokeStyle": "#58CB78", "lineWidth": "7" });
        item.addChild(item.boxBorder);
    }

}

//选中发光效果
export function addGlowFilter(item) {
    //创建一个发光滤镜
    var glowFilter = new GlowFilter("#fff10c", 20, 0, 0);
    //设置滤镜集合为发光滤镜
    item.filters = [glowFilter];
}
//移除发光效果
export function removeGlowFilter(item) {
    item.filters = []
}

// 移出选中
export function removeSelect( item, callback ) {
    item.bgColor = ""
    item.boxBorder&&item.boxBorder.destroy()
    item.boxBorder = null;
}

// 抖动效果
export function shakeJoggle(el) {
    let timers = null;
    if (el.shaking) {
        return
    }
    el.shaking = true;
    //先获取图片自身所在的left值
    let posX = el.x;
    let shakeArr = [];
    let count = 0;
    
    //抖动频率数组
    for(var i= 5; i>0; i-=1){
        shakeArr.push(i,-i)
    }

    el.shaking = false;
    shakeArr.push(0);
    timers = setInterval(() => {
        //左右移动效果
        el.x = posX + shakeArr[count];
        count++;
        if (count === shakeArr.length) {
            el.shaking = false;
            
            clearInterval(timers);
        }
    },50)

}


// 添加勾
export function addRight( item, position, callback ) {
    let iconRight = new Laya.Image();
    iconRight.width = 50;
    iconRight.height = 50;
    iconRight.right = -25;
    iconRight.top = -25;
    iconRight.zOrder = 6;
    iconRight.skin = "https://img.qlchat.com/qlLive/activity/image/CHZWFN94-NMOQ-VYAK-1583319374909-MP49D16G151N.png";
    item.iconRight = iconRight;
    item.addChild(iconRight);
}

export function removeRight( item,callback ) {
    item.removeChild(item.iconRight);
}

// 添加背景
let stageBg = "https://img.qlchat.com/qlLive/activity/image/JLCD9WFW-LCLJ-8HC3-1585886382354-5PEWXH36PRMD.jpg";
export function addBg(views,url=stageBg, callback) {
    
    let bg = new Laya.Image();
    bg.top = 0;
    bg.bottom = 0;
    bg.left = 0;
    bg.right =0;
    bg.skin = url;
    if (views) {
        views.addChild(bg);
        views.zOrder = 1;
    } else {
        Laya.stage.addChild(bg);
        bg.zOrder = 1;
        
    }
}



export function countdown(views, second = 30,callback) {
    let box = new Laya.Box();
    box.width = 120;
    box.height = 120;
    box.top = 50;
    box.right = 50;
    
    let sp = new Laya.Sprite();
    sp.graphics.drawCircle(60, 60, 60, "#fff", "#fcdb79", 10);
    
    var times = new Laya.Label();
    times.text =second;
    times.color = "#92574f";
    times.fontSize = 60;
    times.bold = true;
    times.centerX= 0;
    times.centerY = 5;
    times.align = 'center';
    times.valign = 'middle';

    
    box.addChild(sp);
    box.addChild(times);
    views.countdown = box;
    views._second = second;
    views.addChild(box);

    views.inv = setInterval(() => {
        second--;
        times.text = second;
        views._second = second;
        if (second <= 0) {
            views.inv && clearInterval(views.inv);
            callback && callback();
        }

        
    },1000)

}

export function removeCountdown(views) {
    views.removeChild(views.countdown);
    views.inv && clearInterval(views.inv);

}
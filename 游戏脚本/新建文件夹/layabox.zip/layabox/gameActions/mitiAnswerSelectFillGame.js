/**
 * 
 *  多种答案的填空游戏交互
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight,removeRight,countdown ,removeCountdown, addGlowFilter, removeGlowFilter} from '../util/gameActions'
let audioBgStop = "https://img.qlchat.com/qlLive/activity/image/MRBYOO25-CJR6-AQGZ-1583224359908-D23JZJQ97MB4.png";
let audioBgPlay = "https://img.qlchat.com/qlLive/activity/image/RFBLQ3VA-8YLS-S3PP-1583224365636-6RJ2D4PZAHIV.png";
export default class SortGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.curOnlyAns = null;
        this.gameOver = false;
        this.selectNum = 1;
        // 箭头的图片数组
        this.arrowArr = [
            "https://img.qlchat.com/qlLive/activity/image/X2YERB47-QW2F-R7YY-1589458834042-9DS3M2REDK9C.png",
            "https://img.qlchat.com/qlLive/activity/image/3JSB1434-QY2M-PURK-1589452322809-TDG1UGYRUHJN.png",
            "https://img.qlchat.com/qlLive/activity/image/WVSS9QA3-OOG6-WFF3-1589456687600-TK38JIXOC2N2.png",
            "https://img.qlchat.com/qlLive/activity/image/77RVDOZK-P1QW-IBQ3-1589452319756-K2Q1GL65LX4J.png"
        ],
        this.trumpetArr = []
    }

    init({scenes,maxAns,AnsArr,boxArr,allAnswerArr,finalImg}) {
        this.AnsArr = AnsArr;// 答案数组
        this.boxArr = boxArr;// 选项数组
        this.allAnswerArr = allAnswerArr;// 总答案数组
        this.finalImg = finalImg;// 游戏结束前要展示的图片路径数组
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        // this.initPlay(objArr);
        this.initClick();
    }

    // 录音初始化
    initPlay(objArr){
        objArr.forEach((v,i) => {
            this.initPlayer({
                viewMiddle:this.scenes.view_middle,
                url:v.url,
                position:v,
                index:i
            });
        })
    }

    // 点击初始化
    initClick() {
        this.AnsArr.forEach((element,i) => {
            element.target.on(Laya.Event.CLICK,this,this.ansClick);
        });
        this.boxArr.forEach((element,) => {
            element.target.on(Laya.Event.CLICK,this,this.boxClick);
        });
    }

    // 答案点击事件
    ansClick(e){
        if (e.target.isSelect || this.gameOver) {
            return;
        }
        if(!this.curBox){
            this.removeAnsSelect();
            this.curAns = e.target;
            this.addAnsSelect();
            return;
        }
        this.curAns = e.target;
        let boxIndex = this.boxArr.findIndex(v => v.target === this.curBox);
        if(this.boxArr[boxIndex].answerArr.findIndex(v => v === e.target) > -1){
            if(!this.curOnlyAns){
                let index = this.allAnswerArr.findIndex((v,ind) => {
                    return boxIndex === v.findIndex(vv => vv === e.target)
                })
                this.curOnlyAns = this.allAnswerArr[index]
            }
            if(this.curOnlyAns.findIndex(v => v === e.target) === boxIndex){
                this.curBox.off(Laya.Event.CLICK)
                addSelect(this.curBox)
                addRight(this.curBox);
                let _img = new Laya.Image();
                let ansImg;
                ansImg = this.curAns._children[0];
                let ansIndex = this.AnsArr.findIndex(v => v.target === e.target);
                if(this.AnsArr[ansIndex].direction >= 0){
                    _img.skin = this.arrowArr[this.AnsArr[ansIndex].direction]
                }else{
                    _img.skin = ansImg.skin;
                }
                if(this.AnsArr[ansIndex].scale){
                    _img.scaleX = this.AnsArr[ansIndex].scale;
                    _img.scaleY = this.AnsArr[ansIndex].scale;
                }
                _img.centerX = 0;
                _img.centerY = 0;
                _img.zOrder = 5;
                this.curBox.addChild(_img)

                this.curAns = null;
                this.curBox = null;
                this.selectNum++;
                this.gameAction('right');
                if (this.selectNum > this.maxAns) {
                    if(this.finalImg){
                        setTimeout(() => {
                            this.drawPic(0);
                        }, 1000);
                        return;
                    }
                    this.gameOver = true;
                    this.gameAction('success')
                }  
            }else{
                this.curAns = null
                shakeJoggle(e.target)
                this.gameAction('wrong')
            }
        }else{
            this.curAns = null
            shakeJoggle(e.target)
            this.gameAction('wrong')
        }
    }

    //盒子点击事件
    boxClick(e){
        if (e.target.isSelect || this.gameOver) {
            return;
        }
        if(!this.curAns){
            this.removeBoxSelect();
            this.curBox = e.target;
            this.addBoxSelect();
            let index = this.boxArr.findIndex(v => v.target === e.target);
            console.log(index)
            if(this.boxArr[index].type === 'direction'){
                let arr = this.AnsArr.filter(v => v.direction >= 0);
                arr.forEach(v => addGlowFilter(v.target));
                setTimeout(() => {
                    arr.forEach(v => removeGlowFilter(v.target));
                }, 1000);
            }else if(this.boxArr[index].type === 'number'){
                let arr = this.AnsArr.filter(v => v.direction === undefined);
                arr.forEach(v => addGlowFilter(v.target));
                setTimeout(() => {
                    arr.forEach(v => removeGlowFilter(v.target));
                }, 1000);
            }
            return;
        }
        this.curBox = e.target;
        let boxIndex = this.boxArr.findIndex(v => v.target === this.curBox);
        if(this.boxArr[boxIndex].answerArr.findIndex(v => v === this.curAns) > -1){
            if(!this.curOnlyAns){
                let index = this.allAnswerArr.findIndex((v,ind) => {
                    return boxIndex === v.findIndex(vv => vv === this.curAns)
                })
                this.curOnlyAns = this.allAnswerArr[index]
            }
            if(this.curOnlyAns.findIndex(v => v === this.curAns) === boxIndex){
                this.curBox.off(Laya.Event.CLICK)
                addSelect(this.curBox)
                addRight(this.curBox);
                let _img = new Laya.Image();
                let ansImg;
                ansImg = this.curAns._children[0];
                let ansIndex = this.AnsArr.findIndex(v => v.target === this.curAns);
                if(this.AnsArr[ansIndex].direction >= 0){
                    _img.skin = this.arrowArr[this.AnsArr[ansIndex].direction]
                }else{
                    _img.skin = ansImg.skin;
                }
                if(this.AnsArr[ansIndex].scale){
                    _img.scaleX = this.AnsArr[ansIndex].scale;
                    _img.scaleY = this.AnsArr[ansIndex].scale;
                }
                _img.centerX = 0;
                _img.centerY = 0;
                _img.zOrder = 5;
                this.curBox.addChild(_img);

                this.removeAnsSelect()
                this.curBox = null;
                this.selectNum++;
                this.gameAction('right');
                if (this.selectNum > this.maxAns) {
                    if(this.finalImg){
                        setTimeout(() => {
                            this.drawPic();
                        }, 1000);
                        return;
                    }
                    this.gameOver = true;
                    this.gameAction('success')
                }   
            }else{
                this.curBox = null
                shakeJoggle(this.curAns);
                this.removeAnsSelect();
                this.gameAction('wrong')
            }
        }else{
            this.curBox = null
            shakeJoggle(this.curAns);
            this.removeAnsSelect();
            this.gameAction('wrong')
        }
    }

    //绘制最后要出现的图片
    drawPic(){
        let i = this.allAnswerArr.findIndex(v => v === this.curOnlyAns)
        this.finalImg.target.skin = this.finalImg.urlArr[i];
        setTimeout(() => {
            this.gameOver = true;
            this.gameAction('success');
            return;
        }, 1000);
    }
    addBoxSelect() {
        this.curBox.isSelect = true;
        addSelect(this.curBox)
    }

    addAnsSelect() {
        this.curAns.isSelect = true;
        addGlowFilter(this.curAns)
    }

    removeBoxSelect() {
        if (this.curBox) {
            this.curBox.isSelect = false;
            removeSelect(this.curBox);
        }
        this.curBox=null
    }

    removeAnsSelect() {
        if (this.curAns) {
            this.curAns.isSelect = false;
            removeGlowFilter(this.curAns);
        }
        this.curAns=null
    }


    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            parmas.second = this.second - this.view_middle._second
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }


    //*****************************音频**********************************************************************
    initPlayer({ url, viewMiddle, position,index }) {
        if (!viewMiddle) {
            return;
        }
        let trumpt = new Laya.Image();
        trumpt.width = 63;
        trumpt.height = 46;
        trumpt.zOrder = 10;
        trumpt.left = position.left;
        trumpt.bottom = position.bottom;
        trumpt.url = url;
        this.trumpetArr.push(trumpt)
        this.handleEnded(index);
        viewMiddle.addChild(trumpt);

        trumpt.on(Laya.Event.CLICK, this, (e) => {this.playTitleSound(index)});
    }
   
    handleEnded(index){
        this.isPlaying = false;
        this.trumpetArr[index].audioAni&&Laya.timer.clear(this, this.trumpetArr[index].audioAni);
        this.trumpetArr[index].skin = audioBgStop;
    }

    // 播放题目声音
    playTitleSound(index) {
        Laya.SoundManager.stopAllSound();
        // 允许重复播放
        if (this.isPlaying) {
            Laya.SoundManager.stopSound(this.url);
            this.trumpetArr[index].audioAni&&Laya.timer.clear(this, this.trumpetArr[index].audioAni);
        }
        this.isPlaying = true;
        this.trumpetArr[index].skin = audioBgPlay;
        Laya.SoundManager.playSound(this.trumpetArr[index].url, 1, new Laya.Handler(this, (e) => {this.handleEnded(index)}));
        

        // 音频动画
        this.trumpetArr[index].audioAni = (e) => {
            if (this.trumpetArr[index].skin== audioBgStop) {
                this.trumpetArr[index].skin = audioBgPlay;

            } else {
                this.trumpetArr[index].skin = audioBgStop;
            }
        }
        Laya.timer.frameLoop(20, this, this.trumpetArr[index].audioAni);
    }

}
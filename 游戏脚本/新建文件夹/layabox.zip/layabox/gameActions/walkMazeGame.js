
/**
 * 
 *  走迷宫游戏交互
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight,removeRight,countdown ,removeCountdown, addGlowFilter} from '../util/gameActions'

export default class SortGame{
    constructor() { 
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 0
    }

    init({scenes,AnsArr,boxArr,targetArr,maxAns,imgObj}) {
        this.AnsArr = AnsArr;//移动方向跟坐标的数组
        this.boxArr = boxArr;//点击元素的的数组
        this.targetArr = targetArr;//移动的物体的数组
        this.imgObj = imgObj;//游戏结束后出现的图片路径对象
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initClick();
    }


    initClick() {
        this.boxArr.forEach((element) => {
            element.target.on(Laya.Event.CLICK,this,this.clickHandle);
        });
    }

    clickHandle(e) {
        let box = e.target;
        if (box.hasRight) {
            return;
        }
        let index = this.boxArr.findIndex(v => box === v.target);
        if (this.boxArr[index].direction === this.AnsArr[this.selectNum].direction) {
            this.targetArr[0].x = this.AnsArr[this.selectNum].position.x;
            this.targetArr[0].y = this.AnsArr[this.selectNum].position.y;
            this.onCorrectClick(e);
        } else {
            this.onErrorClick(e);
        }

    }

    //错误效果
    onErrorClick(e) {
        if (this.gameOver) {
            return;
        }
        e.stopPropagation();
        shakeJoggle(e.target)
    }

    //正确
    onCorrectClick(e) {
        if (this.gameOver) {
            return;
        }
        ++this.selectNum;
        if (this.selectNum === this.maxAns) {
            if(this.imgObj){
                let _img = new Laya.Image();
                _img.skin = this.imgObj.url
                _img.x = this.imgObj.position.x;
                _img.y = this.imgObj.position.y;
                _img.scaleX = this.imgObj.scale||1;
                _img.scaleY = this.imgObj.scale||1;
                 _img.zOrder = 6;
                this.scenes.view_middle.addChild(_img);
                setTimeout(() => {
                    this.gameOver = true;
                    removeCountdown(this.view_middle);
                    this.gameAction('success');
                    return;
                },3000)
            }

            this.gameOver = true;
            removeCountdown(this.view_middle);
            this.gameAction('success');
        }   
    }



    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            parmas.second = this.second - this.view_middle._second
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }

}
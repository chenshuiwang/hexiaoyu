/**
 * 
 *  连线（多连）游戏交互
 * 
 **/ 
import drawLine from '../util/drowLine'
import { addSelect, removeSelect, shakeJoggle, addRight } from '../util/gameActions'

export default class DrowLineGame{
    constructor() { 
        this.curCar = null;
        this.curBox = null;
        this.lineNumber = 0;
        this.selected = []
    }

    init({scenes,carArr,boxArr,maxLines}) {
        this.carArr = carArr;
        this.boxArr = boxArr;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxLines = maxLines||carArr.length;
        this.initClick();
    }


    initClick() {
        this.carArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.carClick);
        });
        this.boxArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.carBoxClick);
        });
    }

    // 车子点击事件
    carClick(e) {
        if (this.curCar) {
            removeSelect(this.curCar);
        }
        this.curCar = e.target
        addSelect(e.target);
        this.isDrawLine()
    }

    // 盒子点击事件
    carBoxClick(e) {
        if (this.curBox) {
            removeSelect(this.curBox);
        }
        this.curBox = e.target
        addSelect(e.target);
        this.isDrawLine()
    }

    // 画线
    drawSomething(box_one, box_two) {
        drawLine({
            box_one,
            box_two,
            scenes:this.scenes,
            views:this.view_middle,
            callback: () => {
                this.lineNumber++;
            }
        })
        addRight(box_one)
        return;
    }    

    // 是否画线
    isDrawLine() {
        if ( (!this.curCar) ||  (!this.curBox)) return;
        if (this.curCar && this.curBox && (this.curCar.name === this.curBox.name)) {
            this.drawSomething(this.curCar,this.curBox)
            this.selected.includes(this.curBox.name) ? {} : this.selected.push(this.curBox.name)
            this.curCar.off(Laya.Event.CLICK)
            this.curCar = null
            this.curBox = null
            this.gameAction('right');
            setTimeout(() => {
                this.lineNumber === this.maxLines  ? this.gameAction('success') : null
            }, 500);
        }
        if (this.curCar && this.curBox && (this.curCar.name !== this.curBox.name)) {
            removeSelect(this.curCar)
            if(!this.selected.includes(this.curBox.name)){
                removeSelect(this.curBox)
            }
            shakeJoggle(this.curCar)
            shakeJoggle(this.curBox)
            this.curCar = null
            this.curBox = null
            console.log("答案错误！")
            this.gameAction('wrong')
        }
    
    }

    clearGame() {
        this.lineNumber = 0;
        this.initClick();

        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
        console.log(`游戏${type}`);
    }




}
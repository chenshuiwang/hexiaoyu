/**
 * 
 *  拼图拖动
 * 1.每个盒子有可填入数量，数量0为不可填入
 * 2.填入后的选项可以设置角度
 * 3.拼图重叠规则 居中遮盖
 * 4.在空白处释放选项，恢复原样，不算错误
 * 5.填错盒子，或者盒子已满，算1次错误
 * 6.成功填入正确盒子，算一次正确
 * 7.所有盒子的可填数量已经全部填入完毕  为游戏成功
 * 
 **/ 

/**
 *boxArr:[
        {
            target: this.box1,//盒子对象
            fillNum: 1,//可填入数量
            key: 1,//用来匹配是否可填
            rotation: 150,  //旋转角度   
        },
    ]
 * AnsArr:[
        {
            target: this.b1,//选项对象
            key:1,    //用来匹配盒子
            rotation: 0,  //旋转角度
        },
    ]
 *
 * @export
 * @class MoveFillGame
 */
export default class MoveFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.gameOver = false;
        this.addedArr = [];
        this.secectIndex = 0;
    }

    init({scenes,boxArr,AnsArr,maxAns}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initMove();
    }


    initMove() {
        this.AnsArr.forEach(ansItem => {
            let element = ansItem.target
            // 记录初始状态
            element.preX = element.x;
            element.preY = element.y;
            element.preZ = element.zOrder;
            // 初始化点击开始
            element.on(Laya.Event.MOUSE_DOWN, this, (e) => {
                if (element.isSelect) {
                    return
                }
                this.isDown = true;
                this.moveTarget = element;
                this.sumX = e.stageX - element.x;
                this.sumY = e.stageY - element.y;
                element.zOrder = 99;
            });
            // 初始化离开事件
            element.on(Laya.Event.MOUSE_UP, this, (e) => {

                // console.log('ansItem', ansItem.name);
                
                this.isDown = false;
                if (this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let mouseX = element.x;
                    let mouseY = element.y;

                    // 判断是否在盒子区释放选项
                    let curBox = this.boxArr.find((boxItem) => {
                        const boxTarget = boxItem.target;
                        if (!boxTarget) {
                            return;
                        }

                        // console.log('element.name:', element.rotation);
                        // console.log('boxItem', boxItem.mutiOption[0].rightRotation);
                        // console.log('mouseX:',mouseX,'boxTarget.x:',boxTarget.x,'boxTarget.width:',boxTarget.width);
                        // console.log('mousey:',mouseY,'boxTarget.y:',boxTarget.y,'boxTarget.width:',boxTarget.height);
                        // console.log('mouseX:', mouseX, 'x+width', boxTarget.x + (boxTarget.width*2));
                        // console.log('<=', (mouseX <= (boxTarget.x + (boxTarget.width*2))));
                        // console.log('>=', (mouseX >= (boxTarget.x - boxTarget.width)));
                        
                        // let inX = mouseX >= boxTarget.x - boxTarget.width && mouseX <= boxTarget.x + (boxTarget.width*2);
                        // let inY = mouseY >= boxTarget.y && mouseY <= (boxTarget.y + (boxTarget.height*2));

                        //console.log('x>>>>', mouseX, (boxTarget.x + boxTarget.width));
                        //console.log('y>>>>', mouseY, (boxTarget.y + boxTarget.height));

                        const inX = mouseX >= boxTarget.x && mouseX <= boxTarget.x + boxTarget.width;
                        const inY = mouseY >= boxTarget.y && mouseY <= boxTarget.y + boxTarget.height;
                        
                        const inKey = ansItem.key === boxItem.key;
                        const hasCn = boxItem.target.hasCn && boxItem.fillNum <= boxItem.target.hasCn;
                        let isRightRotaiton = (element.rotation === boxItem.mutiOption[0].rightRotation)

                        if (Array.isArray(boxItem.mutiOption[0].rightRotation)) {
                            isRightRotaiton = boxItem.mutiOption[0].rightRotation.includes(element.rotation);
                        }
                        // console.log('inX:', inX, 'inY:', inY, 'inKey:', inKey, 'hasCn:', hasCn);
                        return inX && inY && inKey && !hasCn && isRightRotaiton;
                    })
                    // 重置zOrder
                    element.zOrder = element.preZ;

                    // console.log('curBox.key != ansItem.key', curBox.key != ansItem.key);
                    // console.log('!this.isRightRotation(curBox, element)', !this.isRightRotation(curBox, element));

                    if (!curBox) {
                        // 在空白处释放则还原
                        element.x = element.preX;
                        element.y = element.preY;
                        return;
                    } else if(curBox.key != ansItem.key || !curBox.fillNum || (curBox.target.hasCn && curBox.fillNum <= curBox.target.hasCn) || !this.isRightRotation(curBox, element)) {
                        // 放错盒子提示错误
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    } else {
                        // 将选项填入盒子
                        const rotation = element.rotation;
                        curBox.target.addChild(element)
                        if(ansItem.position){
                            element.centerX = ansItem.position.centerX||0;
                            element.centerY = ansItem.position.centerY||0;
                        } else {
                            if (curBox.muti) {
                                // console.log('curBox.mutiOption[this.secectIndex]', curBox.mutiOption[this.secectIndex]);
                                // console.log('this.curBox',curBox)
                                element.x = curBox.mutiOption[this.secectIndex].x;
                                element.y = curBox.mutiOption[this.secectIndex].y;
                                curBox.mutiOption[this.secectIndex].hasMoved = true;
                                this.addedArr.push(element);
                            } else {
                                element.centerX = 0;
                                element.centerY = 0;
                            }
                        }

                        element.rotation = rotation;
                        element.hasMoved = true;

                        if (ansItem.scale) {
                            element.scaleX = ansItem.scale;
                            element.scaleY = ansItem.scale
                        }
                        if (ansItem.rotation) {
                            element.rotation = ansItem.rotation;
                        }
                        element.pivotX = element.width / 2;
                        element.pivotY = element.height / 2;
                        element.isSelect = true;
                        // 可能需要旋转角度
                        element.rotation = curBox.rotation||ansItem.rotation||rotation||'';
                        if (curBox.target.hasCn) {
                            // 记录已经填入多少个选项
                            curBox.target.hasCn++;
                        } else {
                            curBox.target.hasCn = 1;
                        }
                        this.gameAction('right')


                        // 筛选是否还有盒子没填
                        let needFill = this.boxArr.filter((boxItem) => {
                            let boxTarget = boxItem.target;
                            
                            return boxItem.fillNum && (!boxTarget.hasCn || boxItem.fillNum > boxTarget.hasCn)
                        });

                        // 判断是否所有盒子都已成功填入所有选项
                        if (!needFill.length) {
                            this.gameAction('success')
                        }
                    }

                }
                this.moveTarget = null;

            });
            // 初始化移动事件
            this.scenes.on(Laya.Event.MOUSE_MOVE, this, (e) => {
                
                if (this.isDown && this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let x = e.stageX;
                    let y = e.stageY;
                    element.x = x-this.sumX;
                    element.y = y-this.sumY;
                    
                }
            });
        });
    }

    isRightRotation(box, target) {
        this.secectIndex = 0;
        if (box && box.mutiOption && box.mutiOption.length > 0) {
            for (let i = 0; i < box.mutiOption.length; i++) {
                const item = box.mutiOption[i];
                if (!item.hasMoved) {
                    if (Array.isArray(item.rightRotation)) {
                        if (item.rightRotation.includes(target.rotation)) {
                            this.secectIndex = i;

                            return true;
                        }
                    } else {
                        if (item.rightRotation === target.rotation) {
                            this.secectIndex = i;

                            return true;
                        }
                    }
                }
            }
        }

        return false;
    }

    clearGame() {
        this.gameOver = false;
        this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




}
/**
 * 
 *  多答案相加拖动题目
 * 1.每个盒子有可填入数量，数量0为不可填入
 * 2.填入后的选项可以设置角度
 * 3.拼图重叠规则 居中遮盖
 * 4.在空白处释放选项，恢复原样，不算错误
 * 5.填错盒子，或者盒子已满，算1次错误
 * 6.成功填入正确盒子，算一次正确
 * 7.所有盒子的可填数量已经全部填入完毕  为游戏成功
 * 
 **/ 

/**
 *boxArr:[
        {
            target: this.box1,//盒子对象
            fillNum: 1,//可填入数量
            key: 1,//用来匹配是否可填
            rotation: 150,  //旋转角度   
        },
    ]
 * AnsArr:[
        {
            target: this.b1,//选项对象
            key:1,    //用来匹配盒子
            rotation: 0,  //旋转角度
        },
    ]
 *
 * @export
 * @class MoveFillGame
 */
export default class MoveFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.curNum = 0
        this.gameOver = false;
        this.number = 1;// number用于记录当前那个元素可以拖动，用于依次拖动的游戏
        this.addedArr = [];
    }

    init({scenes, boxArr, AnsArr, maxAns, sumArr}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initMove();
    }


    initMove() {
        this.AnsArr.forEach(ansItem => {
            let element = ansItem.target
            // 记录初始状态
            element.preX = element.x;
            element.preY = element.y;
            element.preZ = element.zOrder;
            // 初始化点击开始
            element.on(Laya.Event.MOUSE_DOWN, this, (e) => {
                if (element.isSelect) {
                    return
                }
                this.isDown = true;
                this.moveTarget = element;
                this.sumX = e.stageX - element.x;
                this.sumY = e.stageY - element.y;
                element.zOrder = 99;
            });
            // 初始化离开事件
            element.on(Laya.Event.MOUSE_UP, this, (e) => {
                
                this.isDown = false;
                if (this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let mouseX = element.x+element.width/2;
                    let mouseY = element.y+element.height/2;

                    // 判断是否在盒子区释放选项
                    let curBox = this.boxArr.find((boxItem) => {
                        let boxTarget = boxItem.target;
                        if (!boxTarget) {
                            return;
                        }
                        let inX = mouseX >= boxTarget.x && mouseX <= boxTarget.x + boxTarget.width;
                        let inY = mouseY >= boxTarget.y && mouseY <= boxTarget.y + boxTarget.height;
                        return inX&&inY
                    })
                    // 重置zOrder
                    element.zOrder = element.preZ;

                    //在空白处放置就还原
                    if(!curBox) {
                        console.log('空白')
                        element.x = element.preX;
                        element.y = element.preY;
                        return;
                    }

                    if (this.curNum && !curBox.isSum) {
                        let box = this.boxArr.find(v => v.isSum)
                        if (!box.key.includes(this.curNum + ansItem.key)) {
                            console.log('不对哦',this.curNum,ansItem.key)
                            element.x = element.preX;
                            element.y = element.preY;
                            return;
                        } else {
                            console.log('curNum清零')
                            this.curNum = 0;
                        }
                    }

                    let index = this.boxArr.findIndex(v => v === curBox);
                    let keyIndex = this.boxArr[index].key.findIndex(v => ansItem.key === v);
                    if(!Array.isArray(ansItem.name)){
                        if(Array.isArray(curBox.name)) {
                            let i = curBox.name.findIndex(v =>　v === ansItem.name);
                            if(i > 0 || i === 0) {
                                this.boxArr.forEach(v => v.name = ansItem.name);
                                if (!curBox.isSum) {
                                    this.curNum = ansItem.key;
                                    console.log('设置了this.curNum',this.curNum)
                                }
                            }
                        }else {
                            if(ansItem.name === curBox.name) {
                                this.boxArr.forEach(v => v.name = ansItem.name)
                            }else {
                                console.log('name不对',ansItem.name,curBox.name)
                                element.x = element.preX;
                                element.y = element.preY;
                                return;
                            }
                        }
                    }
                    console.log(curBox.name)
                    if(keyIndex <　0 || !curBox.fillNum || (curBox.target.hasCn && curBox.fillNum <= curBox.target.hasCn)) {
                        // 放错盒子提示错误
                        console.log('犯错')
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    } {
                        // 将选项填入盒子
                        if(curBox.isSum) {
                            this.boxArr.forEach(v => {
                                if(v.type === curBox.type) {
                                    v.name = ansItem.key
                                }
                            })
                        }
                        element.centerX = 0;
                        element.centerY = 0;
                        element.pivotX = element.width / 2;
                        element.pivotY = element.height / 2;
                        element.isSelect = true;
                        curBox.target.addChild(element);
                        if (curBox.target.hasCn) {
                            // 记录已经填入多少个选项
                            curBox.target.hasCn++;
                        } else {
                            curBox.target.hasCn = 1;
                        }
                        ++this.number;
                        ++this.selectNum;
                        this.gameAction('right')


                        // 筛选是否还有盒子没填
                        let needFill = this.boxArr.filter((boxItem) => {
                            let boxTarget = boxItem.target;
                            return boxItem.fillNum && (!boxTarget.hasCn || boxItem.fillNum > boxTarget.hasCn)
                        })

                        // 判断是否所有盒子都已成功填入所有选项
                        if (!needFill.length) {
                            this.gameAction('success')
                        }
                    }

                }
                this.moveTarget = null;

            });
            // 初始化移动事件
            this.scenes.on(Laya.Event.MOUSE_MOVE, this, (e) => {
                if (this.isDown && this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let x = e.stageX;
                    let y = e.stageY;
                    element.x = x-this.sumX;
                    element.y = y-this.sumY;
                    
                }
            });
        });
    }



    clearGame() {
        this.gameOver = false;
        this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




}
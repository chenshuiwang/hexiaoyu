/**
 * 
 *  选择游戏交互
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight, addGlowFilter } from '../util/gameActions'
import audioListPlayer from '../util/audioListPlayer';

export default class ChoiceGame{
    constructor() { 
        this.curCar = null;
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 0;
        this.audioPlayer = null;
    }

    init({scenes,boxArr,AnsArr,ansAduio,maxAns,otherArr,imgArr,finalImg,type,ani,finalAudio,bg_panel}) {
        this.boxArr = boxArr;
        this.AnsArr = AnsArr;
        this.ansAduio = ansAduio;
        this.otherArr = otherArr;
        this.imgArr = imgArr;
        this.finalImg = finalImg;//用于游戏结束的时候，展示的图片
        this.type = type;// 游戏类型，值为"growFilter"为选择正确发光
        this.ani = ani;
        this.finalAudio = finalAudio; // 游戏结束之前播放的音频
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initClick();
        this.audioPlayer = new audioListPlayer(this.ansAduio[this.selectNum], bg_panel);
    }

    initClick() {
        this.boxArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.onErrorClick);
        });
        this.AnsArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.onCorrectClick);
        });
    }

    //错误效果
    onErrorClick(e) {
        if (this.gameOver) {
            return;
        }
        e.stopPropagation();
        shakeJoggle(e.target)
        this.gameAction('wrong');
    }

    //正确
    onCorrectClick(e) {
        if (this.gameOver||e.target.isSelect) {
            return;
        }

        if (e.target != this.AnsArr[this.selectNum]) {
            e.stopPropagation();
            shakeJoggle(e.target)
            this.gameAction('wrong');

            return;
        }

        e.target.isSelect = true;
        this.gameAction('right');
        ++this.selectNum;
        if(this.imgArr){
            let _img = new Laya.Image();
            let index = e.target.name;
            _img.skin = this.imgArr[index];
            _img.centerX = 0;
            _img.centerY = 0;
            _img.zOrder = 5;
            e.target.addChild(_img)
        }
        if(this.type === 'growFilter'){
            addGlowFilter(e.target)
        }else{
            addSelect(e.target)
            addRight(e.target)
        }
        if(this.otherArr){
            let _img = new Laya.Image();
            let ansImg;
            ansImg = e.target._children[0];
            _img.skin = ansImg.skin;
            _img.centerX = 0;
            _img.centerY = 0;
            _img.zOrder = 5;
            _img.scaleX = ansImg.scaleX;
            _img.scaleY = ansImg.scaleY;
            let index = this.otherArr.findIndex(v => v.name === e.target.name)
            this.otherArr[index].addChild(_img);
        }
        
        setTimeout(()=>{
            this.audioPlayer.changUrl(this.ansAduio[this.selectNum]);
            this.audioPlayer.playSound(this.ansAduio[this.selectNum]);
        }, 1000);

        if (this.selectNum >= this.maxAns) {
            if(this.finalImg){
                setTimeout(() => {
                    this.drawPic(0);
                }, 1000);
                return;
            }
            if (this.ani && this.ani.img && this.ani.ani) {
                setTimeout(()=> {
                    this.ani.img.visible = false;
                    this.ani.ani.visible = true;
                    this.ani.ani.play(0, false);
                    setTimeout(()=> {
                        this.gameOver = true;
                        this.gameAction('success');
                    }, 3000);
                }, 2000);
            }else{
                
                // this.titlePlayer.init({
                //     bgPanel:this.scenes.bg_panel,
                //     url:this.finalAudio,
                //     callback: () => {
                //         this.gameOver = true;
                //         this.gameAction('success')
                //     }
                // });
                // return;
                this.gameOver = true;
                this.gameAction('success')
            }
        }   
    }

    // 绘制最后展示的图片
    drawPic(i){
        // 如果 finalImg 是一个数组
        if(Array.isArray(this.finalImg)){
            let num = 0
            this.finalImg.forEach( (v,index) => {
                this.finalImg[index].target.skin = v.urlArr[0];
                num++;
                if(num === this.finalImg.length) {
                    setTimeout(() => {
                        this.gameOver = true;
                        this.gameAction('success');
                        return;
                    }, 1000);
                }
            })
            return;
        }
        this.finalImg.target.skin = this.finalImg.urlArr[i];
        console.log(this.finalImg.target.skin)
        if(this.finalImg.urlArr.length === i+1){
            setTimeout(() => {
                this.gameOver = true;
                this.gameAction('success');
                return;
            }, 1000);
        }else{
            setTimeout(() => {
                this.drawPic(++i);
            }, 2000);
        }
    }


    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
        console.log(`游戏${type}`);
    }

}
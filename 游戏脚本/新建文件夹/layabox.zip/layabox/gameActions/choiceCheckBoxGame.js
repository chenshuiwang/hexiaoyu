/**
 * 
 *  选择游戏交互(带确认框的)
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight, addGlowFilter } from '../util/gameActions'

export default class ChoiceGame{
    constructor() { 
        this.curCar = null;
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 0;
    }

    init({scenes,boxArr,AnsArr,maxAns,checkBox}) {
        this.boxArr = boxArr;
        this.AnsArr = AnsArr;
        this.checkBox = checkBox;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initClick();
    }


    initClick() {
        this.boxArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.onErrorClick);
        });
        this.AnsArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.onCorrectClick);
        });
        this.checkBox.on(Laya.Event.CLICK,this,this.onCheckBoxClick);
    }

    //错误效果
    onErrorClick(e) {
        if (this.gameOver) {
            return;
        }
        e.stopPropagation();
        shakeJoggle(e.target)
        this.gameAction('wrong');
    }

    //正确
    onCorrectClick(e) {
        if (this.gameOver||e.target.isSelect) {
            return;
        }
        e.target.isSelect = true;
        this.gameAction('right');
        ++this.selectNum;
        if(this.type === 'growFilter'){
            addGlowFilter(e.target)
        }else{
            addSelect(e.target)
            addRight(e.target)
        }

    }

    onCheckBoxClick(e) {
        if (this.selectNum >= this.maxAns) {
            this.AnsArr.forEach(v => v.off(Laya.Event.CLICK))
            this.gameOver = true;
            this.gameAction('success');
        } else {
            shakeJoggle(e.target)
        }   
    }

    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
        console.log(`游戏${type}`);
    }

}
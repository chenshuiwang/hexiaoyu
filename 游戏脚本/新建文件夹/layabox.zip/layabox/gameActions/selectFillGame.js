/**
 * 
 *  选择游戏交互
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight,removeRight,addGlowFilter,removeGlowFilter} from '../util/gameActions'
let audioBgStop = "https://img.qlchat.com/qlLive/activity/image/MRBYOO25-CJR6-AQGZ-1583224359908-D23JZJQ97MB4.png";
let audioBgPlay = "https://img.qlchat.com/qlLive/activity/image/RFBLQ3VA-8YLS-S3PP-1583224365636-6RJ2D4PZAHIV.png";
export default class SelectFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 1;
        this.number = 0;
        this.trumpetArr = []
    }

    init({scenes,boxArr,AnsArr,number,otherArr,maxAns,objArr,picArr,growFilterObj,needRight = true,finalImg}) {
        // growFilterObj对象用于存储染色题型的对象
        if(growFilterObj){
            this.AnsArr = growFilterObj.AnsArr;
            this.boxArr = growFilterObj.boxArr;
            this.maxAns = maxAns||this.AnsArr.length;
        }else{
            this.AnsArr = AnsArr;
            this.boxArr = boxArr;
            this.maxAns = maxAns||AnsArr.length;
        }
        this.number = number;
        this.otherArr = otherArr;// otherArr用于存储填空题型需要把答案填在另外的地方的数组
        this.picArr = picArr;// picArr主要是拼图填空类型题目传入，选项跟题目都没有我们想要的图片路径，这时额外传一个图片数组来实现这样的效果
        this.objArr = objArr;// objArr主要用于有多个喇叭的填空游戏
        this.growFilterObj = growFilterObj;
        this.finalImg = finalImg; // 游戏结束后展示的图片对象
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.needRight = needRight; // 是否需要√。
        if(this.objArr){
            this.initPlay(objArr);
        }
        this.initClick();
    }

    initClick() {
        this.AnsArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.ansClick);
        });
        this.boxArr.forEach(element => {
            if(this.growFilterObj){
                element.target.on(Laya.Event.CLICK,this,this.boxClick);
            }else{
                element.on(Laya.Event.CLICK,this,this.boxClick);
            }
        });
    }

    //初始化音频
    initPlay(objArr){
        objArr.forEach((v,i) => {
            this.initPlayer({
                viewMiddle:this.scenes.view_middle,
                url:v.url,
                position:v,
                index:i
            });
        })
    }
    // 答案点击事件
    ansClick(e) {
        if (e.target.isSelect || this.gameOver) {
            return;
        }
        //判断选项框是不是已经选择了
        if(!this.curBox){
            if(this.needRight === false){
                return;
            }
            this.removeAnsSelect();
            this.curAns = e.target;
            if(this.growFilterObj){
                addGlowFilter(this.curAns);
            }else{
                this.addAnsSelect();
            }
            return;
        }
        this.curAns = e.target;
        if (this.curBox.name == this.curAns.name) {
            //判断是不是发光的游戏类型
            if(this.growFilterObj){
                let index = this.boxArr.findIndex(v => v.target === this.curBox);
                this.curAns.skin = this.boxArr[index].imgUrl;
                removeGlowFilter(this.curBox);
                this.curAns.off(Laya.Event.CLICK);
            }else{
                this.curBox.off(Laya.Event.CLICK)
                let _img = new Laya.Image();
                let ansImg;
                this.needRight && addRight(this.curBox)
                ansImg = this.curAns._children[0];
                _img.skin = ansImg.skin;
                _img.centerX = 0;
                _img.centerY = 0;
                _img.zOrder = 5;
                _img.scaleX = ansImg.scaleX;
                _img.scaleY = ansImg.scaleY;
                //判断是否传了otherArr参数，如果传了，那么吧答案填在传入的数组里面
                if(this.otherArr){
                    let index = this.otherArr.findIndex(v => v.name === this.curBox.name)
                    if(this.picArr){
                        _img.skin = this.picArr[index];
                        this.otherArr[index].removeChildren();
                        this.otherArr[index].height = 300;
                        this.curBox.removeChildren();
                        this.curAns.removeChildren()
                    }else{
                        _img.skin = ansImg.skin;
                    }
                    this.otherArr[index].addChild(_img);
                }else{
                    this.curBox.addChild(_img)
                }
            }
            this.curAns = null;
            this.curBox = null;
            this.selectNum++;
            this.gameAction('right');
            if(this.number > 0){
                this.maxAns = this.number;
            }
            if (this.selectNum > this.maxAns) {
                if(this.finalImg){
                    this.drawPic();
                    return;
                }
                this.gameOver = true;
                this.gameAction('success')
            }  

        } else {
            this.curAns = null
            shakeJoggle(e.target)
            this.gameAction('wrong')
        }
    }

    // 换图
    drawPic() {
        console.log(2313)
        setTimeout(() => {
            this.finalImg.target.skin = this.finalImg.url;
            setTimeout(() => {
                this.gameOver = true;
                this.gameAction('success')
            }, 2000);
        }, 1000);
        return;
    }

    // 盒子点击事件
    boxClick(e) {
        if (e.target.isSelect || this.gameOver) {
            return;
        }
        //判断答案是不是已经选择了
        if(!this.curAns){
            console.log(213)
            this.removeBoxSelect();
            this.curBox = e.target;
            if(this.growFilterObj){
                addGlowFilter(this.curBox);
            }else{
                this.addBoxSelect();
            }
            return;
        }
        this.curBox = e.target;
        if (this.curBox.name == this.curAns.name) {
            //判断是不是发光的游戏类型
            if(this.growFilterObj){
                let index = this.boxArr.findIndex(v => v.target === this.curBox);
                this.curAns.skin = this.boxArr[index].imgUrl;
                removeGlowFilter(this.curAns);
                this.curAns.off(Laya.Event.CLICK);
                this.curAns = null;
            }else{
                this.curBox.off(Laya.Event.CLICK);
                let _img = new Laya.Image();
                let ansImg;
                if(this.curAns._children.length === 1){
                    ansImg = this.curAns._children[0];
                }else{
                    ansImg = this.curAns._children[1];
                }
                _img.skin = ansImg.skin;
                this.addBoxSelect();
                addRight(this.curBox)
                _img.centerX = 0;
                _img.centerY = 0;
                _img.zOrder = 5;
                _img.scaleX = ansImg.scaleX;
                _img.scaleY = ansImg.scaleY;
                //判断是否传了otherArr参数，如果传了，那么把答案填在传入的数组里面
                if(this.otherArr){
                    let index = this.otherArr.findIndex(v => v.name === this.curBox.name)
                    if(this.picArr){
                        _img.skin = this.picArr[index];
                        this.otherArr[index].removeChildren();
                        this.otherArr[index].height = 300;
                        this.curBox.removeChildren();
                        this.curAns.removeChildren()
                    }else{
                        _img.skin = ansImg.skin;
                    }
                    this.otherArr[index].addChild(_img);
                }else{
                    this.curBox.addChild(_img)
                }
            }
            this.curBox = null;
            this.removeAnsSelect()
            this.selectNum++;
            this.gameAction('right');
            if(this.number > 0){
                this.maxAns = this.number;
            }
            if (this.selectNum > this.maxAns) {
                this.gameOver = true;
                this.gameAction('success')
            }  

        } else {
            this.curBox = null;
            shakeJoggle(this.curAns);
            this.removeAnsSelect();
            this.gameAction('wrong')
        }
    }

    addBoxSelect() {
        this.curBox.isSelect = true;
        addSelect(this.curBox)
    }

    addAnsSelect() {
        this.curAns.isSelect = true;
        addSelect(this.curAns)
    }

    removeBoxSelect() {
        if (this.curBox) {
            this.curBox.isSelect = false;
            if(this.growFilterObj){
                removeGlowFilter(this.curBox)
            }else{
                removeSelect(this.curBox);
            }
        }
        this.curBox=null
    }

    removeAnsSelect() {
        if (this.curAns) {
            this.curAns.isSelect = false;
            if(this.growFilterObj){
                removeGlowFilter(this.curAns)
            }else{
                removeSelect(this.curAns);
            }
        }
        this.curAns=null
    }



    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }

    //*****************************音频**********************************************************************
    initPlayer({ url, viewMiddle, position,index }) {
        if (!viewMiddle) {
            return;
        }
        let trumpt = new Laya.Image();
        trumpt.width = 63;
        trumpt.height = 46;
        trumpt.zOrder = 10;
        trumpt.left = position.left;
        trumpt.bottom = position.bottom;
        trumpt.url = url;
        this.trumpetArr.push(trumpt)
        this.handleEnded(index);
        viewMiddle.addChild(trumpt);

        trumpt.on(Laya.Event.CLICK, this, (e) => {this.playTitleSound(index)});
    }
   
    handleEnded(index){
        this.isPlaying = false;
        this.trumpetArr[index].audioAni&&Laya.timer.clear(this, this.trumpetArr[index].audioAni);
        this.trumpetArr[index].skin = audioBgStop;
    }

    // 播放题目声音
    playTitleSound(index) {
        Laya.SoundManager.stopAllSound();
        // 允许重复播放
        if (this.isPlaying) {
            Laya.SoundManager.stopSound(this.url);
            this.trumpetArr[index].audioAni&&Laya.timer.clear(this, this.trumpetArr[index].audioAni);
        }
        this.isPlaying = true;
        this.trumpetArr[index].skin = audioBgPlay;
        Laya.SoundManager.playSound(this.trumpetArr[index].url, 1, new Laya.Handler(this, (e) => {this.handleEnded(index)}));
        

        // 音频动画
        this.trumpetArr[index].audioAni = (e) => {
            if (this.trumpetArr[index].skin== audioBgStop) {
                this.trumpetArr[index].skin = audioBgPlay;

            } else {
                this.trumpetArr[index].skin = audioBgStop;
            }
        }
        Laya.timer.frameLoop(20, this, this.trumpetArr[index].audioAni);
    }


}
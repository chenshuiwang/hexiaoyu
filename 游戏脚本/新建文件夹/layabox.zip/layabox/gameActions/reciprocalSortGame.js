/**
 * 
 *  选择游戏交互
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight,removeRight,countdown ,removeCountdown} from '../util/gameActions'
import titlePlayer from '../util/titlePlayer'

export default class SortGame{
    constructor() { 
        this.curBox = null;
        this.gameOver = false;
    }

    init({scenes,titleUrl,AnsArr,second=30,boxObj,imgPosition}) {
        this.AnsArr = AnsArr;
        this.numberUrl = [
            "https://media.qlchat.com/qlLive/activity/file/NRE3K7UA-3SV2-1PHR-1588209456050-NYO5VWGS5FRT.mp3",
            "https://media.qlchat.com/qlLive/activity/file/8B5PGHJH-YMZ4-WV3B-1588209336090-242C92LAKN5D.mp3",
            "https://media.qlchat.com/qlLive/activity/file/DBUKSSTQ-N67A-27HI-1588209339666-67MWE7N2EGPG.mp3",
            "https://media.qlchat.com/qlLive/activity/file/32MRYY9W-SGAJ-3R6Z-1588209343171-YG75WEA1VL96.mp3",
            "https://media.qlchat.com/qlLive/activity/file/INTCU47O-ZWMP-1QQ8-1588209346283-C47XLPEPJF9Y.mp3",
            "https://media.qlchat.com/qlLive/activity/file/ZOHFKJ4E-RK37-ZVWH-1588209349678-1JB5HWV5746C.mp3",
            "https://media.qlchat.com/qlLive/activity/file/AUL25R46-TGOP-KCBN-1588209352693-YXWHXVY9588Z.mp3",
            "https://media.qlchat.com/qlLive/activity/file/TKX6M3W5-FAY5-Q87M-1588209355841-OEFJFPLKCK7B.mp3",
            "https://media.qlchat.com/qlLive/activity/file/UMZY6M1V-66JJ-L41X-1588209359237-1X8ZXU1X1LKR.mp3",
            "https://media.qlchat.com/qlLive/activity/file/TIJSOB7N-MRFD-44KS-1588209362529-AD9PD8LAOCGY.mp3",
            "https://media.qlchat.com/qlLive/activity/file/PTR6JPXE-8GAY-RMKP-1588209374617-A44P7DDGNPVM.mp3"
        ],
        this.boxObj = boxObj;
        this.titleUrl = titleUrl;
        this.selectNum = AnsArr.length;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = AnsArr.length;
        this.second = second;
        this.isplayAudios = false;
        this.isClick = false;
        this.initTitlePlayer()
        this.initClick();
        this.initBoxText();
        // this.initCountdown();
    }

    //点击事件初始化
    initClick() {
        this.AnsArr.forEach((element,index) => {
            if(typeof(element) === 'object'){
                element.target.on(Laya.Event.CLICK,this,(e) => {this.clickHandle(e,index)});
            }else{
                element.on(Laya.Event.CLICK,this,this.clickHandle);
            }
            this.initAnsArr(element)
        });
    }

    //盒子点击事件
    clickHandle(e,index) {
        let box = e.target;
        if (box.hasRight) {
            return;
        }
        if (box.name == this.selectNum) {
            this.onCorrectClick(e,index);
        } else {
            this.onErrorClick(e);
            // this.clearAllSelect();
        }

    }
    
    initTitlePlayer() {
        this.titlePlayer = new titlePlayer();
        this.titlePlayer.init({
            bgPanel:this.scenes.bg_panel,
            url:this.titleUrl,
            callback:()=>{
                this.scencesClick()
            }

        });
    }

    scencesClick(){
        if(this.isplayAudios){
            return;
        }
        if(this.selectNum != this.AnsArr.length){
            return;
        }
        this.isClick = false;
        let second = 10;
        let inv = setInterval(() => {
            this.isplayAudios = true;   
            if (second < 6) {
                clearInterval(inv);
                this.isplayAudios = false;
                this.isClick = true;
                return;
            }
            this.changeText(second);
            Laya.SoundManager.stopAllSound();
            Laya.SoundManager.playSound(this.numberUrl[second], 1, new Laya.Handler(this, (e) => {}));
            second--;
        },1000)
        
    }

    //初始化倒计时
    initCountdown() {
        // removeCountdown(this.view_middle)
        // countdown(this.view_middle, this.second, () => {
        //     this.initCountdown();
        //     this.clearAllSelect()
        // })
    }

    //初始化数字
    initBoxText(){
        let box = new Laya.Box();
        box.right = 225;
        box.centerX = this.boxObj.centerX||0;
        box.centerY = this.boxObj.centerY||0;
        box.width = 138;
        box.height = 147;
        box.zOrder = 10;
        this.curBox = box;
        this.scenes.view_middle.addChild(this.curBox);
        let _img = new Laya.Image();
        _img.skin = this.boxObj.imgUrl;
        _img.centerX = 0;
        _img.centerY = 0;
        _img.zOrder = 6;
        if (this.boxObj.imgPosition) {
            for (let key in this.boxObj.imgPosition) {
                _img[key]=this.boxObj.imgPosition[key]
            }
            
        }
        this.curBox.addChild(_img);
        
        let num = new Laya.TextArea();
        num.disabled = 'true';
        num.centerX = 0;
        num.centerY = 0;
        num.zOrder = 6;
        num.fontSize = 130;
        num.align = 'center';
        num.valign = 'middle'
        this.numBox = num;
        this.curBox.addChild(this.numBox);
        this.changeText('10')
    }
    
    //改变数字
    changeText(number){
        this.numBox.text = number;
    }

    //初始化答案数组
    initAnsArr(element){
        let num = new Laya.TextArea()
        num.disabled = 'true';
        num.centerX = 0;
        num.centerY = 0;
        num.zOrder = 6;
        num.fontSize = 130;
        num.text = element.target.name.toString();
        num.align = 'center';
        num.valign = 'middle'
        this.numBox = num;
        element.target.addChild(this.numBox);
    }

    clearAllSelect() {
        this.selectNum = this.AnsArr.length
        this.AnsArr.forEach(element => {
            element.hasRight = false;
            // removeSelect(element);
            // removeRight(element);
        });
        
    }

    //错误效果
    onErrorClick(e) {
        if (this.gameOver||!this.isClick) {
            return;
        }
        e.stopPropagation();
        shakeJoggle(e.target);
    }

    //正确
    onCorrectClick(e,index) {
        if (this.gameOver||!this.isClick) {
            return;
        }
        Laya.SoundManager.stopAllSound();
        Laya.SoundManager.playSound(this.numberUrl[this.selectNum], 1, new Laya.Handler(this, (e) => {}));
        e.target.removeChildren(1);
        e.target.hasRight = true;
        this.changeText(e.target.name.toString())
        --this.selectNum;
        if (this.selectNum < 1) {
            setTimeout(() => {
                Laya.SoundManager.playSound(this.numberUrl[1], 1, new Laya.Handler(this, (e) => {}));
            }, 10);
            Laya.SoundManager.stopAllSound();
            this.gameOver = true;
            removeCountdown(this.view_middle)
            this.gameAction('success')
        }   
    }



    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            parmas.second = this.second - this.view_middle._second
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }

}
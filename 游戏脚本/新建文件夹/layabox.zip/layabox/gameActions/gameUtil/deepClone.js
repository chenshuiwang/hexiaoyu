/**
 * 点击按钮旋转角度
 */
export default class deepClone {

    constructor(id, target){
        this.id = id;
        this.target = target;
    }

    onClick() {
        this.target.rotation += this.rotation;
    }
}
/**
 * 点击按钮旋转角度
 */
export default class ButtonRotation {

    constructor(button, target, rotation){
        this.button = button;
        this.target = target;
        this.rotation = rotation;
        this.button.on(Laya.Event.CLICK,this,this.onClick);
    }

    onClick() {
        if (Array.isArray(this.target)) {
            for (const item of this.target) {
                if (!item.hasMoved) {
                    item.rotation += this.rotation;

                    if (item.rotation === 360) {
                        item.rotation = 0;
                    }
                }
            }
        } else {
            if (!this.target.hasMoved) {
                this.target.rotation += this.rotation;
                if (this.target.rotation === 360) {
                    this.target.rotation = 0;
                }
            }
        }
    }
}
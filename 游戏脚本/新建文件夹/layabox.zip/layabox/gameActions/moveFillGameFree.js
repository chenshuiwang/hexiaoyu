/**
 * 
 *  拼图拖动
 * 1.每个盒子有可填入数量，数量0为不可填入
 * 2.填入后的选项可以设置角度
 * 3.拼图重叠规则 居中遮盖
 * 4.在空白处释放选项，恢复原样，不算错误
 * 5.填错盒子，或者盒子已满，算1次错误
 * 6.成功填入正确盒子，算一次正确
 * 7.所有盒子的可填数量已经全部填入完毕  为游戏成功
 * 
 **/ 

/**
 *boxArr:[
        {
            target: this.box1,//盒子对象 
        },
    ]
 * AnsArr:[
        {
            target: this.b1,//选项对象
        },
    ],
    type: '+' // 运算类型
 *
 * @export
 * @class MoveFillGame
 */
export default class MoveFillGameFree{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.gameOver = false;
    }

    init({scenes, boxArr ,AnsArr, type}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.scenes = scenes;
        this.type = type;
        this.initMove();
    }

    initMove() {
        this.AnsArr.forEach(ansItem => {
            const element = ansItem.target;
            // 记录初始状态
            element.preX = element.x;
            element.preY = element.y;
            element.preZ = element.zOrder;
            // 初始化点击开始
            element.on(Laya.Event.MOUSE_DOWN, this, (e) => {
                this.isDown = true;
                this.moveTarget = element;
                this.sumX = e.stageX - element.x;
                this.sumY = e.stageY - element.y;
                if (element.isSelect) {
                    element._parent.zOrder = 9;
                }
                element.zOrder = 99;
            });
            // 初始化离开事件
            element.on(Laya.Event.MOUSE_UP, this, (e) => {
                this.isDown = false;
                if (this.moveTarget == element) {
                    let mouseX = element.x + element.width / 2;
                    let mouseY = element.y + element.height / 2;

                    // 判断是否在盒子区释放选项
                    const curBox = this.boxArr.find((boxItem) => {
                        const boxTarget = boxItem.target;

                        if (!boxTarget) {

                            return false;
                        }

                        if (element.isSelect) {
                            if (boxTarget.name === element._parent.name) {

                                return false;
                            }
                            mouseX = (element.x + element._parent.x) + element.width / 2;
                            mouseY = (element.y + element._parent.y) + element.height / 2;
                        }

                        // console.log('mouseX:', mouseX, 'boxTarget.x:', boxTarget.x + boxTarget.width);
                        // console.log('mousey:', mouseY, 'boxTarget.y:' ,boxTarget.y + boxTarget.height);
                        const inX = mouseX >= boxTarget.x && mouseX <= boxTarget.x + boxTarget.width;
                        const inY = mouseY >= boxTarget.y && mouseY <= boxTarget.y + boxTarget.height;
                        // console.log('inX:', inX, 'inY:', inY);
                        return inX && inY;
                    });

                    // 重置zOrder
                    if (element.isSelect) {
                        element._parent.zOrder = 0;
                    }
                    element.zOrder = element.preZ;

                    // 在空白处放置就还原
                    if (!curBox) {
                        if (element.isSelect) {
                            element._parent.hasCn = null;
                            this.resetElement(element);
                        } else {
                            element.x = element.preX;
                            element.y = element.preY;
                        }

                        return false;
                    }

                    if (curBox.target.hasCn) {
                        // 拖动位置已有元素则交换位置
                        this.changeTarget(curBox, element);
                        return false;
                    } else {
                        this.rightAction(curBox, ansItem);
                    }

                    this.isRight();
                }

                this.moveTarget = null;
            });

            // 初始化移动事件
            this.scenes.on(Laya.Event.MOUSE_MOVE, this, (e) => {
                if (this.isDown && this.moveTarget == element) {
                    element.x = e.stageX - this.sumX;
                    element.y = e.stageY - this.sumY;
                }
            });
        });
    }

    // 拖动位置已有元素则交换位置
    changeTarget(curBox, element) {
        const curBoxElement = curBox.target._children[0];
        const elementParent = element._parent;

        if (element.isSelect) {
            this.setElement(curBox, element);
            this.setElement(elementParent, curBoxElement);
        } else {
            this.setElement(curBox, element);
            this.resetElement(curBoxElement); 
        }

    }

    // 错误
    wrongAction() {
        for (const item of this.boxArr) {
            this.resetElement(item.target._children[0])
            item.target.hasCn = null;
        }
        
        this.gameAction('wrong');
    }

    // 正确
    rightAction(curBox, ansItem) {
        const element = ansItem.target;

        if (element.isSelect) {
            element._parent.hasCn = null;
        }

        this.setElement(curBox, element);
    }

    isRight() {
        // 筛选是否还有盒子没填
        const needFill = this.boxArr.filter((boxItem) => {

            return !boxItem.target.hasCn;
        })

        // 判断是否所有盒子都已成功填入所有选项
        if (!needFill.length) {
            const answer = eval(`${this.boxArr[0].target._children[0].name}${this.type}${this.boxArr[1].target._children[0].name}===${this.boxArr[2].target._children[0].name}`);

            if (answer) {
                this.gameAction('right');      
                this.gameOver = true;
                this.gameAction('success');
            } else {
                setTimeout(() => {
                   this.wrongAction(); 
                }, 1000);
            }
        }
    }

    // 设置元素
    setElement(curBox, element){
        if (curBox.target && curBox.target.name) {
            curBox = curBox.target;
        }
        element.centerX = 0;
        element.centerY = 0;
        element.isSelect = true;
        element.zOrder = element.preZ;

        curBox.addChild(element);
        curBox.hasCn = 1;
    }

    // 重置元素
    resetElement(element) {
        element.centerX = NaN;
        element.centerY = NaN;
        element.x = element.preX;
        element.y = element.preY;
        element.isSelect = false;
        element.zOrder = element.preZ;
        this.scenes.view_middle.addChild(element);
    }

    clearGame() {
        this.gameOver = false;
        this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }
}
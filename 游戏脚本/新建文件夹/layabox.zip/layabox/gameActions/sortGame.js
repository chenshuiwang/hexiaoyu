/**
 * 
 *  倒计时排序交互
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight,removeRight,countdown ,removeCountdown, addGlowFilter, removeGlowFilter} from '../util/gameActions'

export default class SortGame{
    constructor() { 
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 1;
        this.arrowObj = [
            "https://img.qlchat.com/qlLive/activity/image/G1ZTL1SO-C37B-7XPA-1589438577402-CGINNVDXMGZM.png",
            "https://img.qlchat.com/qlLive/activity/image/TI5CS7C5-3FDC-9IXR-1589438592064-A5TNL62VPMDW.png",
            "https://img.qlchat.com/qlLive/activity/image/AFT828A2-CUSN-6XJ9-1589438579433-5U18UGUSAABG.png",
            "https://img.qlchat.com/qlLive/activity/image/VAM9JCW7-Z3CE-OH5U-1589438589162-CAP9KXS5W4OT.png"
        ]
    }

    init({scenes,AnsArr,second=30,boxArr,type,finalImg,maxAns,needEmpty}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;//boxArr数组,实现点击正确给指定数组添加子元素
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.type = type;//type决定排序游戏的类型，“growFilter”选择正确的选项产生发光效果，“addNumber”选对之后再正确的选项里添加序号，“chess”选对之后在选项里新增图片,"addPic"选对之后改变选项图片
        this.finalImg = finalImg;//在游戏结束的时候显示的一张图片，主要用在走棋子的游戏类型里面
        this.needEmpty = needEmpty;//点错需不需要重置
        this.maxAns = maxAns||AnsArr.length;
        this.second = second;
        this.initClick();
        // 如果传入了类型那就不加载倒计时
        if(!this.type){
            this.initCountdown();
        }
    }


    initClick() {
        this.AnsArr.forEach((element,index) => {
            if(typeof(element.target) === 'object'){
                element.target.on(Laya.Event.CLICK,this,(e) => {this.clickHandle(e,index)});
            }else{
                element.on(Laya.Event.CLICK,this,this.clickHandle);
            }
        });
    }
    //点击处理
    clickHandle(e,index) {
        let box = e.target;
        if (box.hasRight) {
            console.log(213344)
            return;
        }
        if (box.name == this.selectNum) {
            this.onCorrectClick(e,index);
        } else {
            this.onErrorClick(e);
            if(!this.needEmpty){
                this.clearAllSelect();
            } 
        }

    }
    //初始化倒计时
    initCountdown() {
        removeCountdown(this.view_middle)
        countdown(this.view_middle, this.second, () => {
            this.initCountdown();
            this.clearAllSelect()
        })
    }
    //清楚所有的选择框
    clearAllSelect() {
        this.selectNum = 1
        this.AnsArr.forEach(element => {
            if(typeof(element.target) === 'object'){
                element.target.hasRight = false;
                removeSelect(element.target);
                removeRight(element.target);
            }else{
                element.hasRight = false;
                removeSelect(element);
                removeRight(element);
            }
            
        });
        
    }

    //错误效果
    onErrorClick(e) {
        if (this.gameOver) {
            return;
        }
        if(this.type === 'growFilter'&&!this.needEmpty){
            this.AnsArr.forEach(v => removeGlowFilter(v))
        }else if(this.type === 'addPic'){
            this.AnsArr.forEach(v => {
                if(v.target._children.length > 1){
                    v.target._children.length = 1
                }
            })
        }else if(this.type === 'addNumber'&&!this.needEmpty){
            this.AnsArr.forEach(v => {
                if(v._children.length > 1){
                    v._children.length = 1
                }
            })
        }else if(this.type === 'chess'){
            shakeJoggle(this.curBox)
        }
        
        e.stopPropagation();
        shakeJoggle(e.target);
        this.gameAction('wrong')
    }

    //正确
    onCorrectClick(e,index) {
        if (this.gameOver) {
            return;
        }
        e.target.hasRight = true;
        if(this.type === 'growFilter'){
            addGlowFilter(e.target);
        }else if(this.type === 'addNumber'){
            let num = new Laya.TextArea();
            num.text = this.selectNum;
            num.disabled = 'true';
            num.centerX = 0;
            num.centerY = 0;
            num.zOrder = 10;
            num.fontSize = 50;
            num.align = 'center';
            num.valign = 'middle'
            e.target.addChild(num)
        }else if(this.type === 'chess'){
            let _img = new Laya.Image();
            let ind = this.AnsArr.findIndex(v => v.target === e.target);
            _img.skin = this.arrowObj[this.AnsArr[ind].index];
            console.log(_img.skin)
            _img.centerX = 0;
            _img.centerY = 0;
            _img.zOrder = 5;
            e.target.addChild(_img);
        }else if(this.type === 'addPic'){
            let _img = new Laya.Image();
            let ind = this.AnsArr.findIndex(v => v.target === e.target);
            _img.skin = this.AnsArr[ind].imgUrl;
            _img.centerX = 0;
            _img.centerY = 0;
            if(this.AnsArr[ind].position){
                if(this.AnsArr[ind].position.rotation){
                    _img.rotation = this.AnsArr[ind].position.rotation;
                    console.log(this.AnsArr[ind].position.rotation)
                }
                if(this.AnsArr[ind].position.centerX){
                    _img.centerX = this.AnsArr[ind].position.centerX;
                }
                if(this.AnsArr[ind].position.centerY){
                    _img.centerY = this.AnsArr[ind].position.centerY;
                }
            }
            _img.zOrder = 5;
            e.target.addChild(_img);
        }
        else{
            addSelect(e.target)
            addRight(e.target)
        }
        //判断是否传入boxArr数组,实现点击正确给指定数组添加子元素
        if(this.boxArr){
            let box = this.boxArr.filter(v => this.AnsArr[index].key === v.key);
            let _img = new Laya.Image();
            _img.skin = e.target._children[0].skin;
            _img.centerX = 0;
            _img.centerY = 0;
            _img.zOrder = 5;
            box[0].target.removeChildren();
            box[0].target.addChild(_img)
        }
        ++this.selectNum;
        this.gameAction('right');
        if (this.selectNum > this.maxAns) {
            if(this.finalImg){
                setTimeout(() => {
                    this.scenes.view_middle.removeChildren();
                    let _img = new Laya.Image();
                    _img.skin = this.finalImg.url;
                    _img.centerX = 0;
                    _img.centerY = 0;
                    _img.zOrder = 5;
                    this.scenes.view_middle.addChild(_img);
                    setTimeout(() => {
                        this.gameOver = true;
                        removeCountdown(this.view_middle)
                        this.gameAction('success')
                    }, 1000);
                }, 1000);
                return;
            }
            this.gameOver = true;
            removeCountdown(this.view_middle)
            this.gameAction('success')
        }   
    }



    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        console.log('gameAction:',type)
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            parmas.second = this.second - this.view_middle._second
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }

}
/**
 * 
 *  连线游戏交互
 * 
 **/ 
import drawLine from '../util/drowLine'
import { addSelect, removeSelect, shakeJoggle, addRight } from '../util/gameActions'
import audioPlayer from '../util/audioAppPlayer';
let audioBgStop = "https://img.qlchat.com/qlLive/activity/image/MRBYOO25-CJR6-AQGZ-1583224359908-D23JZJQ97MB4.png";
let audioBgPlay = "https://img.qlchat.com/qlLive/activity/image/RFBLQ3VA-8YLS-S3PP-1583224365636-6RJ2D4PZAHIV.png";
export default class DrowLineGame{
    constructor() { 
        this.curCar = null;
        this.curBox = null;
        this.lineNumber = 0;
        this.trumpetArr = [];
    }

    init({scenes,carArr,boxArr,maxLines,objArr,finalAudio,finalImg,container}) {
        this.carArr = carArr;
        this.boxArr = boxArr;
        this.finalAudio = finalAudio; // 游戏结束之前播放的音频
        this.finalImg = finalImg; // 游戏结束之前展示的图片
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxLines = maxLines||boxArr.length;
        if(objArr){
            this.initPlay(objArr);
        }
        if (finalImg) {
            this.initFinalImg()
        }
        this.initClick();
    }


    initClick() {
        this.carArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.carClick);
        });
        this.boxArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.carBoxClick);
        });
    }

    initPlay(objArr){
        objArr.forEach((v,i) => {
            this.initPlayer({
                viewMiddle:this.view_middle,
                url:v.url,
                position:v,
                index:i
            });
        })
    }

    initFinalImg(){
        this.finalImg.visible = false;
    }

    // 车子点击事件
    carClick(e) {
        if (this.gameOver) {
            return;
        }
        if (this.curCar) {
            removeSelect(this.curCar);
        }
        this.curCar = e.target
        addSelect(e.target);
        this.isDrawLine()
    }

    // 盒子点击事件
    carBoxClick(e) {
        if (this.gameOver) {
            return;
        }
        if (this.curBox) {
            removeSelect(this.curBox);
        }
        this.curBox = e.target;
        addSelect(e.target);
        this.isDrawLine();
    }

    // 画线
    drawSomething(box_one, box_two) {
        drawLine({
            box_one,
            box_two,
            scenes: this.scenes,
            views: this.view_middle,
            callback: () => {
                this.lineNumber++;
            }
        })
        addRight(box_two)
        return;
    }    

    // 是否画线
    isDrawLine() {
        if ( (!this.curCar) ||  (!this.curBox)) return;
        if (this.curCar && this.curBox && (this.curCar.name === this.curBox.name)) {
            this.drawSomething(this.curCar,this.curBox);
            
            console.log("匹配成功！")
            this.curCar.off(Laya.Event.CLICK)
            this.curBox.off(Laya.Event.CLICK)
            this.curCar = null
            this.curBox = null
            this.gameAction('right');
            setTimeout(() => {
                if (this.lineNumber === this.maxLines) {
                    if (this.finalAudio) {
                        this.gameOver = true;
                        this.titlePlayer1 = new audioPlayer(
                            this.finalAudio,
                            this.scenes.bg_panel,
                            null,
                            true,
                            () => {
                                this.gameAction('success');
                            }
                        );
                        return;
                    }
                    if (this.finalImg) {
                        setTimeout(() => {
                            this.view_middle._children.forEach((v) => {
                                if (v.visible) {
                                    v.visible = false;
                                }
                            })
                            this.finalImg.visible = true;
                            
                            setTimeout(() => {
                                this.gameOver = true;
                                this.gameAction('success')
                            }, 1000);
                        }, 1000);
                        return;
                    }
                }
                this.lineNumber === this.maxLines  ? this.gameAction('success') : null
            }, 500);
        }
        if (this.curCar && this.curBox && (this.curCar.name !== this.curBox.name)) {
            removeSelect(this.curCar)
            removeSelect(this.curBox)
            shakeJoggle(this.curCar)
            shakeJoggle(this.curBox)
            this.curCar = null
            this.curBox = null
            console.log("答案错误！")
            this.gameAction('wrong')
        }
    
    }

    clearGame() {
        this.lineNumber = 0;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
        console.log(`游戏${type}`);
    }

    //*****************************音频**********************************************************************
    initPlayer({ url, viewMiddle, position,index }) {
        if (!viewMiddle) {
            return;
        }
        let trumpt = new Laya.Image();
        trumpt.width = 63;
        trumpt.height = 46;
        trumpt.zOrder = 10;
        trumpt.left = position.left;
        trumpt.bottom = position.bottom;
        trumpt.url = url;
        this.trumpetArr.push(trumpt)
        this.handleEnded(index);
        viewMiddle.addChild(trumpt);

        trumpt.on(Laya.Event.CLICK, this, (e) => {this.playTitleSound(index)});
    }
   
    handleEnded(index){
        this.isPlaying = false;
        this.trumpetArr[index].audioAni&&Laya.timer.clear(this, this.trumpetArr[index].audioAni);
        this.trumpetArr[index].skin = audioBgStop;
    }

    // 播放题目声音
    playTitleSound(index) {
        Laya.SoundManager.stopAllSound();
        // 允许重复播放
        if (this.isPlaying) {
            Laya.SoundManager.stopSound(this.url);
            this.trumpetArr[index].audioAni&&Laya.timer.clear(this, this.trumpetArr[index].audioAni);
        }
        this.isPlaying = true;
        this.trumpetArr[index].skin = audioBgPlay;
        Laya.SoundManager.playSound(this.trumpetArr[index].url, 1, new Laya.Handler(this, (e) => {this.handleEnded(index)}));
        

        // 音频动画
        this.trumpetArr[index].audioAni = (e) => {
            if (this.trumpetArr[index].skin== audioBgStop) {
                this.trumpetArr[index].skin = audioBgPlay;

            } else {
                this.trumpetArr[index].skin = audioBgStop;
            }
        }
        Laya.timer.frameLoop(20, this, this.trumpetArr[index].audioAni);
    }


}
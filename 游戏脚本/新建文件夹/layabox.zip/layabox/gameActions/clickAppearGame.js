/**
 * 
 *  点击显示游戏
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight } from '../util/gameActions'

export default class SelectFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.curPic = null;
        this.gameOver = false;
        this.ansNum = 0;
        this.boxNum = 0;
        this.position = null;
        this.scale = 0;
    }

    init({scenes,sumArr,picArr,maxAns,position,scale,maxArrNum,maxBoxNum}) {
        // this.AnsArr = AnsArr;
        // this.boxArr = boxArr;
        this.sumArr = sumArr;
        this.boxArr = sumArr[0].boxArr;
        this.maxBoxNum = maxBoxNum||this.boxArr.length - 1;
        if(this.sumArr.length === 2){
            this.AnsArr = sumArr[1].boxArr;
            this.maxArrNum = maxArrNum||this.AnsArr.length;
            this.maxAns = maxAns||this.AnsArr.length;
        }
        this.curPic = picArr;
        this.position = position;
       
        this.scale = scale||1;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.initConfirm();
        this.initClick();
    }

    initConfirm(){
        let box = new Laya.Box();
        box.right = 225;
        if(this.position === 'top'){
            box.top = 70
        }else{
            box.bottom = 30;
        }
        box.width = 194;
        box.height = 109;
        box.zOrder = 10;
        this.confirmBox = box;
        this.scenes.addChild(this.confirmBox);
        let _img = new Laya.Image();
        _img.skin = 'https://img.qlchat.com/qlLive/activity/image/P5E9LKJX-YVCS-DC8E-1587380536222-6IO8GO2JZ3LO.png';
        _img.centerX = 0;
        _img.centerY = 0;
         _img.zOrder = 5;
         box.addChild(_img);
    }
    initClick() {
        if(this.AnsArr){
            this.AnsArr.forEach(element => {
                element.isSelect = false;
                element.on(Laya.Event.CLICK,this,this.ansClick);
            });
        }
        this.boxArr.forEach(element => {
            element.isSelect = false;
            element.on(Laya.Event.CLICK,this,this.boxClick);
        });
        this.confirmBox.on(Laya.Event.CLICK,this,this.isTrue)
    }
    // 答案点击事件
    ansClick(e) {
        if (this.gameOver) {
            return;
        }
        this.curAns = e.target;
        if(!this.curAns.isSelect){
            this.addSelect(this.curAns);
            let _img = new Laya.Image();
            _img.skin = this.curPic.length === 1 ? this.curPic[0].skin : this.curPic[1].skin;
            _img.centerX = 0;
            _img.centerY = 0;
            _img.zOrder = 5;
            if(this.scale != 1){
                _img.scaleX = this.scale;
                _img.scaleY = this.scale;
            }
            this.curAns._img = _img; 
            this.curAns.addChild(_img);
            this.ansNum += 1;
            if(this.ansNum === this.AnsArr.length){
                this.gameAction('right');
            }
        }else{
            this.removeSelect(this.curAns);
            this.curAns._img&&this.curAns._img.destroy();
            this.ansNum -= 1;
        }
        e.target.isSelect = !e.target.isSelect;
        console.log(e.target.isSelect)
        
    }

    // 盒子点击事件
    boxClick(e) {
        if (this.gameOver) {
            return;
        }
        this.curBox = e.target
        this.addSelect(this.curBox);
        if(!this.curBox.isSelect){
            this.addSelect(this.curBox);
            let _img = new Laya.Image();
            let ansImg = this.curBox._children[0];
            _img.skin = this.curPic[0].skin;
            _img.centerX = 0;
            _img.centerY = 0;
            _img.zOrder = 5;
            _img.scaleX = ansImg.scaleX;
            _img.scaleY = ansImg.scaleY;
            this.curBox._img = _img;
            this.curBox.addChild(_img);
            this.boxNum += 1;
            if(this.boxNum === this.maxBoxNum){
                this.gameAction('right')
            }
        }else{
            this.removeSelect(this.curBox);
            this.curBox._img&&this.curBox._img.destroy()
            this.boxNum -= 1;
        }
        e.target.isSelect = !e.target.isSelect;
    }

    isTrue(){
        if(this.boxNum == this.maxBoxNum && this.ansNum === this.maxArrNum){
            addSelect(this.confirmBox);
            addRight(this.confirmBox);
            this.gameOver = true;
            this.gameAction('success');
        }else{
            shakeJoggle(this.confirmBox)
            this.gameAction('wrong')
        }
    }

    addSelect(e) {
        addSelect(e);
    }

    removeSelect(e) {
        if (e) {
            removeSelect(e);
        }
        e=null
    }

    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
                this.scenes.removeChildren()
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




}
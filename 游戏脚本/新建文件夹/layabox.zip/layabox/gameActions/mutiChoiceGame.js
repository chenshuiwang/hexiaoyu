/**
 * 
 *  多选游戏
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight, addGlowFilter,removeGlowFilter } from '../util/gameActions'
import titlePlayer from '../util/titlePlayer'
export default class MutiChoiceGame{
    constructor() { 
        this.curBoxArr = null;
        this.checkBoxPosition = null;

        this.checkBox = null;
        this.lineNumber = 0;
        this.selected = [];
        this.answer = [0,0]
    }

    init({scenes,curBoxArr,checkBoxPosition,type}) {
        this.curBoxArr = curBoxArr;
        this.checkBoxPosition = checkBoxPosition;
        this.type = type;//type参数为判断是否为选中高亮的游戏类型
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.initCheckBox();
        this.initClick();
    }

    initCheckBox(){
        let box = new Laya.Box();
        box.centerX = 0;
        box.bottom = 30;
        box.width = 194;
        box.height = 109;
        box.zOrder = 10;
        for (let key in this.checkBoxPosition) {
            box[key]=this.checkBoxPosition[key]
        }
        this.checkBox = box;
        this.scenes.view_middle.addChild(this.checkBox);
        let _img = new Laya.Image();
        _img.skin = 'https://img.qlchat.com/qlLive/activity/image/934P3F6V-SEC2-PRNM-1587635400113-Y4K9E6EW895N.png';
        _img.centerX = 0;
        _img.centerY = 0;
         _img.zOrder = 5;
         this.checkBox.addChild(_img);
    }

    initClick() {
        this.curBoxArr.forEach((item, index) => {
            item.ansArr.forEach(ite => {
                ite.target && ite.target.on(Laya.Event.CLICK,this,(e)=>{this.boxClick(ite,index)});
            })
        })
        this.checkBox.on(Laya.Event.CLICK,this,this.checkBoxClick);
    }

    // 点击事件
    boxClick(item,index) {
        let curBox = item.target;
        if (curBox.hasSelect&&!this.type) {
            return;
        }
        this.curBoxArr[index].ansArr.forEach(ite => {
            ite.target.hasSelect = false;
            removeSelect(ite.target)
        })

        curBox.hasSelect = true;
        if (item.audioSrc) {
            // Laya.SoundManager.stopAllSound();
            // Laya.SoundManager.playSound(item.audioSrc, 1, new Laya.Handler(this, (e) => {}));
            this.titlePlayer = new titlePlayer();
            this.titlePlayer.init({
                bgPanel:this.scenes.bg_panel,
                url:item.audioSrc
            });
        }
        if(this.type === 'growFilter'){
            if(!item.target.isClicked){
                addGlowFilter(curBox)
            }else{
                removeGlowFilter(curBox);
                curBox.hasSelect = false;
            }
            item.target.isClicked = !item.target.isClicked;
            this.gameAction('right')
            console.log(item.target.isClicked);
        }else{
            addSelect(curBox);
        }
    }


    //确认框点击事件
    checkBoxClick() {
        let isSomeWrong = this.curBoxArr.filter((item, index) => {
            let aA = item.ansArr.filter(boxItem => {

                if (boxItem.target.hasSelect&&!boxItem.isRight) {
                    shakeJoggle(boxItem.target)
                    shakeJoggle(this.checkBox)
                    return true;
                }else if (boxItem.isRight && !boxItem.target.hasSelect) {
                    shakeJoggle(this.checkBox)
                    return true;
                }
                return false;
            })

            return  (aA && aA.length)
            
        })
        if (isSomeWrong && isSomeWrong.length) {
            //去除所有滤镜
            if(this.type === 'growFilter'){
                this.curBoxArr.forEach(v => {
                    v.ansArr.forEach(vv => {
                        removeGlowFilter(vv.target);
                        vv.target.hasSelect = false;
                        vv.target.isClicked = false;
                    })
                })
            }
            this.gameAction('wrong')
        } else {
            this.gameAction('success')
        }
    }

    clearGame() {
        this.lineNumber = 0;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
                this.scenes.removeChildren();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
        console.log(`游戏${type}`);
    }




}
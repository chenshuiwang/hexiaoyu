/**
 * 
 *  点连成线游戏交互
 * 
 **/ 
import { shakeJoggle, addGlowFilter ,removeGlowFilter} from '../util/gameActions'

export default class MoveFillGame{
    constructor() { 
        this.curPoint = null;
        this.gameOver = false;
        this.linesNum = 0;
        this.showLineKey = [];
        this.showLineArr = [];
    }

    init({scenes,pointArr,lineArr,maxLine,rightKeyArray,worngKeyArray}) {
        this.pointArr = pointArr;// 点数组，点击对图形进行切割
        this.lineArr = lineArr;// 线数组
        this.maxLine = maxLine;
        this.rightKeyArray = rightKeyArray;
        this.worngKeyArray = worngKeyArray;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.initVisible();
        this.initClick();
    }

    //点击初始化
    initClick() {
        this.pointArr.forEach(element => {
            element.target.on(Laya.Event.CLICK,this,this.onPointClick);
        });
    }

    //初始化元素是否可见
    initVisible() {
        this.lineArr.forEach(v => v.target.visible = false);
    }

    // 切割点的点击事件
    onPointClick(e) {
        if(this.curPoint){
            let index1 = this.pointArr.findIndex(v => v.target === this.curPoint);
            let index2 = this.pointArr.findIndex(v => v.target === e.target);
            if(this.pointArr[index1].key === this.pointArr[index2].key &&　index1 != index2){
                addGlowFilter(e.target);
                this.lineArr.forEach(v => {
                    if (v.key === this.pointArr[index1].key) {
                        v.target.visible = true;
                        this.showLineKey.push(v.key);
                        this.showLineArr.push(v);
                    }
                })
                this.curPoint._children.forEach(v => {
                    if( v.name === 'black') {
                        v.visible = true
                    }
                })
                this.linesNum++;
                this.gameAction('right');
                if (this.rightKeyArray && this.rightKeyArray.length > 0) {
                    if (this.checkLine(this.rightKeyArray)) {
                        setTimeout(() => {
                            this.gameOver = true;
                            this.gameAction('success');
                        }, 1000); 

                        removeGlowFilter(this.curPoint);
                        this.curPoint = null;

                        return true;
                    }
                }

                if (this.worngKeyArray && this.worngKeyArray.length > 0) {
                    if (this.checkLine(this.worngKeyArray)) {
                        setTimeout(()=>{
                            for (const item of this.showLineArr) {
                                item.target.visible = false;
                            }
    
                            this.linesNum = 0;
                            this.showLineKey = [];
                            this.showLineArr = [];
    
                            this.gameAction('wrong');  
                        }, 1000);

                        removeGlowFilter(this.curPoint);
                        this.curPoint = null;

                        return false;
                    }
                }

                if (this.linesNum >= this.maxLine) {
                    setTimeout(()=>{
                        for (const item of this.showLineArr) {
                            item.target.visible = false;
                        }

                        this.linesNum = 0;
                        this.showLineKey = [];
                        this.showLineArr = [];

                        this.gameAction('wrong');  
                    }, 1000);
                }

                removeGlowFilter(this.curPoint);
                this.curPoint = null;
            }else{
                this.gameAction('wrong');
                shakeJoggle(this.curPoint);
                removeGlowFilter(this.curPoint);
                this.curPoint._children.forEach(v => {
                    if( v.name === 'black') {
                        v.visible = true
                    }
                })
                this.curPoint = null;
            }
        }else{
            this.pointArr.forEach(v => removeGlowFilter(v.target));
            this.curPoint = e.target;
            addGlowFilter(this.curPoint);
            this.curPoint._children.forEach(v => {
                if( v.name === 'black') {
                    v.visible = false
                }
            })
        }
    }

    checkLine(array = []) {
        let result = false;
        if (this.showLineKey.length > 0) {
            for (const item of array) {
                if (this.showLineKey.sort().toString() === item.toString()) {
                    result = true;
                }
            }
        }

        return result;
    }

    clearGame() {
        this.gameOver = false;
        // this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }
    
    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle && this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }
}

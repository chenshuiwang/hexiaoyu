/**
    拖动旋转游戏

 **/ 


export default class MoveFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.selectArr = []
        this.gameOver = false;
        this.isStart = true;
        this.number = 0
    }

    init({scenes,boxArr,AnsArr,maxAns,spinArr,spinRotation}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.spinArr = spinArr;// 旋转按钮数组
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.spinRotation = spinRotation || 90;
        this.initClick();
        this.initVisible();
        this.initMove();
    }


    initMove() {
        this.AnsArr.forEach(ansItem => {
            let element = ansItem.target
            // 记录初始状态
            element.preX = element.x;
            element.preY = element.y;
            element.preZ = element.zOrder;
            // 初始化点击开始
            element.on(Laya.Event.MOUSE_DOWN, this, (e) => {
                if (element.isSelect) {
                    return
                }
                this.isDown = true;
                this.moveTarget = element;
                this.sumX = e.stageX - element.x;
                this.sumY = e.stageY - element.y;
                element.zOrder = 99;
            });
            // 初始化离开事件
            element.on(Laya.Event.MOUSE_UP, this, (e) => {
                
                this.isDown = false;
                if (this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let mouseX = element.x;
                    let mouseY = element.y;
                    // 判断是否在盒子区释放选项
                    let curBox = this.boxArr.find((boxItem) => {
                        let boxTarget = boxItem.target;
                        if (!boxTarget) {
                            return;
                        }
                        // console.log('mouseX:',mouseX,'boxTarget.x:',boxTarget.x,'boxTarget.width:',boxTarget.width)
                        // console.log('mousey:',mouseY,'boxTarget.y:',boxTarget.y,'boxTarget.width:',boxTarget.height)
                        let inX = mouseX >= boxTarget.x && mouseX <= boxTarget.x + boxTarget.width;
                        let inY = mouseY >= boxTarget.y && mouseY <= boxTarget.y + boxTarget.height;
                        let inKey = ansItem.key === boxItem.key;
                        let hasCn = boxItem.target.hasCn && boxItem.fillNum <= boxItem.target.hasCn;
                        // console.log('inX:', inX, 'inY:', inY, 'inKey:', inKey, 'hasCn:', hasCn);
                        return inX && inY && inKey && !hasCn;
                    })
                    // 重置zOrder
                    element.zOrder = element.preZ;
                    if (!curBox) {
                        // 在空白处释放则还原
                        element.x = element.preX;
                        element.y = element.preY;
                        return;
                    }
                    let rightIndex = this.AnsArr.findIndex(v => {
                        if (Array.isArray(ansItem.rotation)) {
                            return  v.rotation.includes(this.curSelect.rotation)
                        }else {
                            return v.rotation === this.curSelect.rotation && v.key === curBox.key
                        }
                    });
                    console.log(curBox.rotation)
                    if (curBox.rotation > -1) {

                        if (Array.isArray(ansItem.rotation)) {
                            if (this.curSelect.rotation != (curBox.rotation + 180) % 360) {
                                rightIndex = -1;
                            }
                        }else {
                            if (this.curSelect.rotation != curBox.rotation) {
                                rightIndex = -1;
                            }else {
                                rightIndex = 0
                            }
                        }
                    }else if (curBox.rotation && Array.isArray(curBox.rotation)) {
                        if (!curBox.rotation.includes(this.curSelect.rotation)) {
                            rightIndex = -1
                        }else {
                            rightIndex = 0
                            curBox.rotation = (this.curSelect.rotation + 180) % 360;
                            console.log(curBox.rotation)
                        }
                    }
                    console.log('rightIndex',rightIndex)
                    if(curBox.key != ansItem.key || !curBox.fillNum || (curBox.target.hasCn && curBox.fillNum <= curBox.target.hasCn) || rightIndex < 0) {
                        // 放错盒子提示错误
                        console.log('错误',this.curSelect.rotation)
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    } else {
                        // 将选项填入盒子
                        element.centerX = 0;
                        element.centerY = 0;
                        if(ansItem.scale){
                            element.scaleX = ansItem.scale;
                            element.scaleY = ansItem.scale
                        }
                        // if(ansItem.rotation && !this.allAnswerArr){
                        //     element.rotation = ansItem.rotation;
                        // }
                        element.pivotX = element.width / 2;
                        element.pivotY = element.height / 2;
                        element.isSelect = true;
                        // 可能需要旋转角度
                        // if(this.allAnswerArr) {
                        //     // console.log('起IQ古怪',this.curSelect.rotation)
                        //     element.rotation = this.curSelect.rotation;
                        // }else{
                        //     element.rotation = curBox.rotation||ansItem.rotation||'';
                        // }
                        curBox.target.addChild(element);
                        if (curBox.target.hasCn) {
                            // 记录已经填入多少个选项
                            curBox.target.hasCn++;
                        } else {
                            curBox.target.hasCn = 1;
                        }

                        this.number++;
                        if (Array.isArray(ansItem.rotation)) {
                            if(!curBox.rotation){
                                curBox.rotation = this.curSelect.rotation;
                            }else {
                                
                            }
                        }
                        if(rightIndex > 0) {
                            this.AnsArr[rightIndex].rotation = this.AnsArr[0].rotation;
                            this.AnsArr[rightIndex].position = this.AnsArr[0].position;
                        }
                        this.AnsArr.shift();
                        console.log(this.AnsArr)
                        this.initVisible();
                        ++this.selectNum;
                        this.gameAction('right')


                        // 筛选是否还有盒子没填
                        let needFill = this.boxArr.filter((boxItem) => {
                            let boxTarget = boxItem.target;
                            return boxItem.fillNum && (!boxTarget.hasCn || boxItem.fillNum > boxTarget.hasCn)
                        })

                        // 判断是否所有盒子都已成功填入所有选项
                        if (!needFill.length) {
                            this.gameAction('success')
                        }
                    }

                }
                this.moveTarget = null;

            });
            // 初始化移动事件
            this.scenes.on(Laya.Event.MOUSE_MOVE, this, (e) => {
                if (this.isDown && this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let x = e.stageX;
                    let y = e.stageY;
                    element.x = x-this.sumX;
                    element.y = y-this.sumY;
                }
            });
        });
    }
    
    // 初始化点击事件
    initClick() {
        this.spinArr.forEach(element => {
            element.target.on(Laya.Event.CLICK,this,this.onSpinClick);
        });
    }

    //初始化元素是否可视化
    initVisible(){
        if(this.AnsArr.length === 0){
            this.gameAction('success');
            return;
        }
        this.curSelect = this.AnsArr[0].target;
        this.curSelect.visible = true;
        this.AnsArr.forEach((v,i) => { 
            if( i > 0 ) {
                v.target.visible = false;
            }
        })
    }

    //旋转按钮点击
    onSpinClick(e) {
        this.curSelect.pivotX = this.curSelect.width / 2;
        this.curSelect.pivotY = this.curSelect.height / 2;
        this.curSelect.rotation += this.spinRotation;
        if(this.curSelect.rotation > 360 || this.curSelect.rotation === 360 || this.curSelect.rotation % 360 === 0){
            this.curSelect.rotation = this.curSelect.rotation % 360;
        }
    }

    clearGame() {
        this.gameOver = false;
        this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




}
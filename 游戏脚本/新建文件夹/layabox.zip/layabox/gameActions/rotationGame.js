/**
 * 
 *  选择游戏交互
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight, addGlowFilter } from '../util/gameActions'
import titlePlayer from '../util/titlePlayer'

export default class ChoiceGame{
    constructor() { 
        this.gameOver = false;
        this.rotation = 0;
    }

    init({scenes, rightRotation, leftRotation, fontRota, backRota, leftButton, rightButton, rotationAdd}) {
        this.rightRotation = rightRotation;
        this.leftRotation = leftRotation;
        this.scenes = scenes;
        this.fontRota = fontRota;
        this.backRota = backRota;
        this.btnleft = leftButton;
        this.btnright = rightButton;
        this.rotationAdd = rotationAdd;
        this.initClick();
    }

    initClick() {
        this.btnleft.on(Laya.Event.CLICK, this, this.leftButtonClick);
        this.btnright.on(Laya.Event.CLICK, this, this.rightButtonClick);
    }

    // 顺时针旋转
    leftButtonClick(e) {
        // console.log('leftButtonClick', e.target);
        if (this.gameOver) {
            return;
        }

        this.rotation += this.rotationAdd;

        if (this.rotation % 360 === this.leftRotation) {
            this.gameSuccess();
        }

        Laya.Tween.to(this.backRota, {rotation: this.rotation}, 500, Laya.Ease.circOut, null, 0, true);
    }

    // 逆针旋转
    rightButtonClick(e) {
        // console.log('rightButtonClick', e.target);
        if (this.gameOver) {
            return;
        }

        this.rotation -= this.rotationAdd;

        if (this.rotation % 360 === this.rightRotation) {
            this.gameSuccess();
        }

        Laya.Tween.to(this.backRota, {rotation: this.rotation}, 500, Laya.Ease.circIn, null, 0, true);
    }

    gameSuccess() {
        this.gameAction('right');
       
        this.gameOver = true;
        this.gameAction('success'); 
    }       

    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
        console.log(`游戏${type}`);
    }

}
/**
 * 
 *  分数字游戏，就是把一定数量的东西分给不同的人的几种分法
 * 1.每个盒子有可填入数量，数量0为不可填入
 * 2.填入后的选项可以设置角度
 * 3.拼图重叠规则 居中遮盖
 * 4.在空白处释放选项，恢复原样，不算错误
 * 5.填错盒子，或者盒子已满，算1次错误
 * 6.成功填入正确盒子，算一次正确
 * 7.所有盒子的可填数量已经全部填入完毕  为游戏成功
 * 
 **/ 

/**
 *boxArr:[
        {
            target: this.box1,//盒子对象
            fillNum: 1,//可填入数量
            key: 1,//用来匹配是否可填
            rotation: 150,  //旋转角度   
        },
    ]
 * AnsArr:[
        {
            target: this.b1,//选项对象
            key:1,    //用来匹配盒子
            rotation: 0,  //旋转角度
        },
    ]
 *
 * @export
 * @class MoveFillGame
 */
import { shakeJoggle } from '../util/gameActions'
import audioPlayer from '../util/audioAppPlayer';

export default class MoveFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.gameOver = false;
        this.number = 1;// number用于记录当前那个元素可以拖动，用于依次拖动的游戏
        this.addedArr = [];
    }

    init({scenes,boxArr,AnsArr,maxAns,AnspositionArr,btnArr,finalAudio}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.AnspositionArr = AnspositionArr;// 从多个答案中选择两个以上到同一个目标中，用于存储答案的位置数组
        this.btnArr = btnArr;// 按钮数组，用于点击然后对游戏进行判断是否正确
        this.finalAudio = finalAudio;// 游戏结束播放的音频
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        if(this.btnArr) {
            this.initClick();
        }
        this.initMove();
    }

    initClick() {
        this.btnArr.forEach(element => {
            element.target.on(Laya.Event.CLICK,this,this.onBtnClick);
        });
    }

    onBtnClick(e){
        let needFill = 0;
        this.boxArr.forEach(v => {
            if(v.target.hasCn){
                needFill += v.target.hasCn;
            }
        })
        if (needFill === this.AnsArr.length) {
            this.gameAction('success')
        }else {
            shakeJoggle(e.target)
        }                
    }

    initMove() {
        this.AnsArr.forEach(ansItem => {
            let element = ansItem.target
            // 记录初始状态
            element.preX = element.x;
            element.preY = element.y;
            element.preZ = element.zOrder;
            // 初始化点击开始
            element.on(Laya.Event.MOUSE_DOWN, this, (e) => {
                if (element.isSelect || this.gameOver) {
                    return
                }
                this.isDown = true;
                this.moveTarget = element;
                this.sumX = e.stageX - element.x;
                this.sumY = e.stageY - element.y;
                element.zOrder = 99;
            });
            // 初始化离开事件
            element.on(Laya.Event.MOUSE_UP, this, (e) => {
                
                this.isDown = false;
                if (this.moveTarget == element) {
                    if (element.isSelect || this.gameOver) {
                        return
                    }

                    let mouseX = element.x+element.width/2;
                    let mouseY = element.y+element.height/2;
                
                    // 判断是否在盒子区释放选项
                    let curBox = this.boxArr.find((boxItem) => {
                        let boxTarget = boxItem.target;
                        if (!boxTarget) {
                            return;
                        }
                        let inX = mouseX >= boxTarget.x && mouseX <= boxTarget.x + boxTarget.width;
                        let inY = mouseY >= boxTarget.y && mouseY <= boxTarget.y + boxTarget.height;
                        return inX&&inY
                    })
                    // 重置zOrder
                    element.zOrder = element.preZ;

                    //在空白处放置就还原
                    if(!curBox) {
                        element.x = element.preX;
                        element.y = element.preY;
                        return;
                    }

                    //判断盒子是否存在key值
                    if(!curBox.key){
                        // 如果key为零或不传，那么就还原
                        if(!ansItem.key){
                            element.x = element.preX;
                            element.y = element.preY;
                            return;
                        }
                        curBox.key = ansItem.key;
                    }
                    // 判断盒子时候存在fillNum
                    if(!curBox.fillNum){
                        let fillNum = 0;
                        this.boxArr.forEach(vv => {
                            if(vv.target.hasCn){
                                fillNum += vv.target.hasCn;
                            }
                        })
                        if(fillNum === 0) {
                            fillNum = 1;
                        }
                        curBox.fillNum = this.AnsArr.length - fillNum;
                        console.log(curBox.fillNum,this.AnsArr.length,fillNum) 
                    }

                    // 当curBox.fillNum是一个数组时
                    let isFill;
                    if (Array.isArray(curBox.fillNum)) {
                        isFill = curBox.fillNum.includes(curBox.target.hasCn + 1);
                        if ( curBox.target.hasCn) {
                            isFill = curBox.fillNum.includes(curBox.target.hasCn + 1);
                            if (isFill) {
                                this.boxArr.forEach(v => {
                                    if (v.name === curBox.name) {
                                        let i = v.fillNum.findIndex(vv => vv === curBox.target.hasCn + 1);
                                        if (i > -1) {
                                            v.fillNum.splice(i,1)
                                        }
                                    }
                                })
                            }
                            
                        } else {
                            isFill = 1
                        }
                    } else {
                        isFill = 1
                    }

                    if (curBox.expecial) {
                        let hasNum = 0, ind;
                        this.boxArr.forEach((vv,ii) => {
                            if (vv.target.hasCn && vv.name != curBox.name) {
                                hasNum += vv.target.hasCn;
                                ind = ii;
                            }
                        })
                        console.log('hasNum',hasNum)
                        if (hasNum > 2 && curBox.target.hasCn) {
                            if (this.boxArr[ind - 1].target.hasCn === 1) {
                                if (ind < 2) {
                                    this.boxArr[2].fillNum = 2;
                                    this.boxArr[3].fillNum = 1;
                                } else {
                                    this.boxArr[0].fillNum = 2;
                                    this.boxArr[1].fillNum = 1;
                                }
                            } else {
                                if (ind < 2) {
                                    this.boxArr[2].fillNum = 1;
                                    this.boxArr[3].fillNum = 2;
                                } else {
                                    this.boxArr[0].fillNum = 1;
                                    this.boxArr[1].fillNum = 2;
                                }
                            }
                        }  
                    }

                    if (curBox.key != ansItem.key || !curBox.fillNum || (curBox.target.hasCn && curBox.fillNum <= curBox.target.hasCn && !Array.isArray(curBox.fillNum))) {
                        // 放错盒子提示错误
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    } else if(ansItem.number&&ansItem.number != this.number){
                        // 不按顺序拖动
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    } else if(!isFill) {
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                    } else {
                        // 将选项填入盒子
                        if (ansItem.position) {
                            element.centerX = ansItem.position.centerX||0;
                            element.centerY = ansItem.position.centerY||0;
                        } else {
                            if (curBox.position&&curBox.position.auto) {
                                element.centerX = curBox.position.arr[this.addedArr.length].centerX;
                                element.centerY = curBox.position.arr[this.addedArr.length].centerY;
                                this.addedArr.push(element);
                            } else {
                                element.centerX = 0;
                                element.centerY = 0;
                            }
                        }
                        //变换位置
                        if (this.AnspositionArr) {
                            let i = curBox.target.hasCn||0;
                            if (ansItem.key instanceof Array) {
                                console.log(curBox.fillNum)
                                element.centerX = this.AnspositionArr[i].centerX||0;
                                element.centerY = this.AnspositionArr[i].centerY||0;
                            }
                            let index = this.AnspositionArr.findIndex(v => v.key === curBox.key);
                            if (index < 0 ) {
                                element.centerX = this.AnspositionArr[i].centerX||0;
                                element.centerY = this.AnspositionArr[i].centerY||0;
                            } else {
                                element.centerX = this.AnspositionArr[index].arr[i].centerX||0;
                                element.centerY = this.AnspositionArr[index].arr[i].centerY||0;
                            }
                        }
                        if (ansItem.scale) {
                            element.scaleX = ansItem.scale;
                            element.scaleY = ansItem.scale
                        }
                        if (ansItem.rotation) {
                            element.rotation = ansItem.rotation;
                        }
                        element.pivotX = element.width / 2;
                        element.pivotY = element.height / 2;
                        element.isSelect = true;
                        // 可能需要旋转角度
                        element.rotation = curBox.rotation||ansItem.rotation||'';
                        curBox.target.addChild(element);
                        if (curBox.target.hasCn) {
                            // 记录已经填入多少个选项
                            curBox.target.hasCn++;
                        } else {
                            curBox.target.hasCn = 1;
                        }
                        ++this.number;
                        ++this.selectNum;
                        this.gameAction('right')

                        // 判断是否盒子是否填完
                        if(this.btnArr){
                            return;
                        }
                        let needFill = 0;
                        this.boxArr.forEach(v => {
                            if(v.target.hasCn){
                                needFill += v.target.hasCn;
                            }
                        })
                        if (needFill === this.maxAns) {
                            if (this.finalAudio) {
                                this.gameOver = true;
                                this.titlePlayer1 = new audioPlayer(
                                    this.finalAudio,
                                    this.scenes.bg_panel,
                                    null,
                                    true,
                                    () => {
                                        this.gameAction('success');
                                    }
                                );
                            } else {
                                this.gameOver = true;
                                this.gameAction('success');
                            }
                        }
                    }

                }
                this.moveTarget = null;

            });
            // 初始化移动事件
            this.scenes.on(Laya.Event.MOUSE_MOVE, this, (e) => {
                if (this.isDown && this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let x = e.stageX;
                    let y = e.stageY;
                    element.x = x-this.sumX;
                    element.y = y-this.sumY;
                    
                }
            });
        });
    }



    clearGame() {
        this.gameOver = false;
        this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




}

/**
 * 
 *  游戏交互
 *  
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight,removeRight,countdown ,removeCountdown} from '../util/gameActions'

export default class reciprocalChoiceGame{
    constructor() { 
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 1;
        this.numberUrl = [
            "https://media.qlchat.com/qlLive/activity/file/NRE3K7UA-3SV2-1PHR-1588209456050-NYO5VWGS5FRT.mp3",
            "https://media.qlchat.com/qlLive/activity/file/8B5PGHJH-YMZ4-WV3B-1588209336090-242C92LAKN5D.mp3",
            "https://media.qlchat.com/qlLive/activity/file/DBUKSSTQ-N67A-27HI-1588209339666-67MWE7N2EGPG.mp3",
            "https://media.qlchat.com/qlLive/activity/file/32MRYY9W-SGAJ-3R6Z-1588209343171-YG75WEA1VL96.mp3",
            "https://media.qlchat.com/qlLive/activity/file/INTCU47O-ZWMP-1QQ8-1588209346283-C47XLPEPJF9Y.mp3",
            "https://media.qlchat.com/qlLive/activity/file/ZOHFKJ4E-RK37-ZVWH-1588209349678-1JB5HWV5746C.mp3",
            "https://media.qlchat.com/qlLive/activity/file/AUL25R46-TGOP-KCBN-1588209352693-YXWHXVY9588Z.mp3",
            "https://media.qlchat.com/qlLive/activity/file/TKX6M3W5-FAY5-Q87M-1588209355841-OEFJFPLKCK7B.mp3",
            "https://media.qlchat.com/qlLive/activity/file/UMZY6M1V-66JJ-L41X-1588209359237-1X8ZXU1X1LKR.mp3",
            "https://media.qlchat.com/qlLive/activity/file/TIJSOB7N-MRFD-44KS-1588209362529-AD9PD8LAOCGY.mp3",
            "https://media.qlchat.com/qlLive/activity/file/PTR6JPXE-8GAY-RMKP-1588209374617-A44P7DDGNPVM.mp3"
        ],
        this.views = null;
    }

    init({scenes,AnsArr,second,boxArr,btnArr,maxAns}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.btnArr = btnArr;
        this.sumArr = [...this.boxArr,...this.AnsArr];
        this.selectArr = [];
        this.isplayaduios = false;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.second = second||10;
        this.initCountdown();
        this.initClick();
    }


    initClick() {
        this.boxArr.forEach(element => { 
            element.on(Laya.Event.CLICK,this,this.onErrorClick);
        });
        this.AnsArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.onCorrectClick);
        });
        this.btnArr.forEach(element => {
            element.target.on(Laya.Event.CLICK,this,this.btnClick);
        });
        this.scenes.bg_panel._children[0].on(Laya.Event.CLICK,this,this.playerClick);
        this.scenes.on(Laya.Event.CLICK,this,this.scenesClick);
        this.sumArr.forEach(e => this.selectArr.push(false))
    }

    onErrorClick(e) {
        if (this.gameOver) {
            return;
        }
        //判断是否点击过播放按钮
        let index = this.sumArr.findIndex(v => v === e.target)
        if(!this.selectArr[index]){
            return;
        }
        this.clearAllInterval();
        this.initCountdown()
        e.stopPropagation();
        shakeJoggle(e.target)
        this.gameAction('wrong');
    }

    btnClick(e){
        if(!this.isplayaduios){
            return;
        }
        let index = this.btnArr.findIndex(v => v.target === e.target);
        let numArr = this.btnArr[index].numArr;
        this.otherArr = this.sumArr.filter(v => v.name != e.target.name)
        let sIndex = this.sumArr.findIndex(v => v.name === e.target.name);
        this.selectArr[sIndex] = true;
        removeCountdown(this.view_middle);
        this.countdown(this.sumArr[sIndex], numArr, () => {
            this.initCountdown();
        })
    }

    initCountdown() {
        this.sumArr.forEach(v => {
            this.initNumber(v)
        })
    }

    playerClick(){
        var end = setInterval(function(){},1);
        var start = (end -100)>0?end-100:0;
        for(var i=start;i<=end;i++){
            this.sumArr.forEach(v => {
                this.initNumber(v)
            })
            clearInterval(i);
        }
    }
    
    scenesClick(){
        if(!this.isplayaduios){
            this.isplayaduios = true;
        }
    }

    //初始化计时器的数字
    initNumber(views){
        let box = new Laya.Box();
        box.width = 120;
        box.height = 120;
        box.centerX = 0;
        box.centerY = 0;
        box.zOrder = 10;
        let sp = new Laya.Sprite();
        sp.graphics.drawCircle(60, 60, 60, "#fff", "#fcdb79", 10);
        
        var times = new Laya.Label();
        times.text =this.second;
        times.color = "#92574f";
        times.fontSize = 60;
        times.bold = true;
        times.centerX= 0;
        times.centerY = 5;
        times.align = 'center';
        times.valign = 'middle';
    
        
        box.addChild(sp);
        box.addChild(times);
        views.addChild(box);
    }

    //数字变换和配音
    onCorrectClick(e) {
        if (this.gameOver||e.target.isSelect) {
            return;
        }
        //判断是否点击过播放按钮
        let index = this.sumArr.findIndex(v => v === e.target)
        if(!this.selectArr[index]){
            return;
        }
        e.target.isSelect = true;
        this.gameAction('right');
        ++this.selectNum;
        addSelect(e.target)
        addRight(e.target)
        if (this.selectNum >= this.maxAns) {
            var end = setInterval(function(){},1);
            var start = (end -100)>0?end-100:0;
            for(var i=start;i<=end;i++){
                this.otherArr.forEach(v => {
                    this.initNumber(v)
                })
                clearInterval(i);
            }
            this.gameOver = true;
            this.gameAction('success')
        }      
    }

    //清除所有的计时器
    clearAllInterval(){
         var end = setInterval(function(){},1);
        var start = (end -100)>0?end-100:0;
        for(var i=start;i<=end;i++){
            this.otherArr.forEach(v => {
                this.initNumber(v)
            })
            clearInterval(i);
        }
    }

    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            parmas.second = this.second - this.view_middle._second
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




    //*******************************倒计时*********************************************** */
    countdown(views, numArr,callback) {
        console.log(numArr)
        let box = new Laya.Box();
        box.width = 120;
        box.height = 120;
        box.centerX = 0;
        box.centerY = 0;
        box.zOrder = 10;
        let sp = new Laya.Sprite();
        sp.graphics.drawCircle(60, 60, 60, "#fff", "#fcdb79", 10);
        
        var times = new Laya.Label();
        let second = numArr.length;
        let index = 0;
        times.text =numArr[index];
        times.color = "#92574f";
        times.fontSize = 60;
        times.bold = true;
        times.centerX= 0;
        times.centerY = 5;
        times.align = 'center';
        times.valign = 'middle';
    
        
        box.addChild(sp);
        box.addChild(times);
        views.countdown = box;
        views._second = numArr[index];
        views.addChild(box);
        this.clearAllInterval()
        
        views.inv = setInterval(() => {
            if (second < 1) {
                views.inv && clearInterval(views.inv);
                callback && callback();
                return
            }
            times.text = numArr[index];
            views._second = numArr[index];
            let urlIndex = this.numberUrl.findIndex((v,i) => i === numArr[index])
            Laya.SoundManager.stopAllSound();
            Laya.SoundManager.playSound(this.numberUrl[urlIndex], 1, new Laya.Handler(this, (e) => {}));
            second--;
            index++;
        },1000)
        
    
    }

}
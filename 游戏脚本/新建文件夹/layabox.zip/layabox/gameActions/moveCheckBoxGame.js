/**
 * 
 *  拼图拖动(带确认框的)
 * 1.每个盒子有可填入数量，数量0为不可填入
 * 2.填入后的选项可以设置角度
 * 3.拼图重叠规则 居中遮盖
 * 4.在空白处释放选项，恢复原样，不算错误
 * 5.填错盒子，或者盒子已满，算1次错误
 * 6.成功填入正确盒子，算一次正确
 * 7.所有盒子的可填数量已经全部填入完毕  为游戏成功
 * 
 **/
import { shakeJoggle } from "../util/gameActions";

 

/**
 *boxArr:[
        {
            target: this.box1,//盒子对象
            fillNum: 1,//可填入数量
            key: 1,//用来匹配是否可填
            rotation: 150,  //旋转角度   
        },
    ]
 * AnsArr:[
        {
            target: this.b1,//选项对象
            key:1,    //用来匹配盒子
            rotation: 0,  //旋转角度
        },
    ]
 *
 * @export
 * @class MoveFillGame
 */
export default class MoveFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.gameOver = false;
        this.number = 1;// number用于记录当前那个元素可以拖动，用于依次拖动的游戏
        this.addedArr = [];
        this.fillNum = 0; // 已经填入盒子的物品数量
    }

    init({scenes,boxArr,AnsArr,maxAns,checkBox}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.checkBox = checkBox;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns || this.AnsArr.length;// 答案的数量
        this.initClick();
        this.initMove();
    }

    initClick() {
        this.checkBox.on(Laya.Event.CLICK,this,this.onCheckBoxClick);
    }

    initMove() {
        this.AnsArr.forEach(ansItem => {
            let element = ansItem.target
            // 记录初始状态
            element.preX = element.x;
            element.preY = element.y;
            element.preZ = element.zOrder;
            // 初始化点击开始
            element.on(Laya.Event.MOUSE_DOWN, this, (e) => {
                if (element.isSelect || this.gameOver) {
                    return
                }
                this.isDown = true;
                this.moveTarget = element;
                this.sumX = e.stageX - element.x;
                this.sumY = e.stageY - element.y;
                element.zOrder = 99;
            });
            // 初始化离开事件
            element.on(Laya.Event.MOUSE_UP, this, (e) => {
                
                this.isDown = false;
                if (this.moveTarget == element) {
                    if (element.isSelect || this.gameOver) {
                        return
                    }

                    let mouseX = element.x + element.width/2;
                    let mouseY = element.y + element.height/2;
                    
                    // 判断是否在盒子区释放选项
                    let curBox = this.boxArr.find((boxItem) => {
                        let boxTarget = boxItem.target;
                        if (!boxTarget) {
                            return;
                        }
                        // console.log('mouseX:',mouseX,'boxTarget.x:',boxTarget.x,'boxTarget.width:',boxTarget.width)
                        // console.log('mousey:',mouseY,'boxTarget.y:',boxTarget.y,'boxTarget.width:',boxTarget.height)
                        let inX = mouseX >= boxTarget.x && mouseX <= boxTarget.x + boxTarget.width;
                        let inY = mouseY >= boxTarget.y && mouseY <= boxTarget.y + boxTarget.height;
                        // console.log(' inX:', inX,', inY:', inY)
                        return inX&&inY
                    })
                    // 重置zOrder
                    element.zOrder = element.preZ;

                    //在空白处放置就还原
                    if(!curBox) {
                        console.log('空白')
                        element.x = element.preX;
                        element.y = element.preY;
                        return;
                    }

                    if(((curBox.key != ansItem.key && JSON.stringify(curBox.key) != JSON.stringify(ansItem.key)) || !curBox.fillNum || (curBox.target.hasCn && curBox.fillNum <= curBox.target.hasCn)) && !curBox.commonKey) {
                        // 放错盒子提示错误
                        // console.log('???')
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    } else if(ansItem.number&&ansItem.number != this.number){
                        // 不按顺序拖动
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    }else {

                        element.centerX = 0;
                        element.centerY = 0;

                        //变换位置
                        if (ansItem.scale) {
                            element.scaleX = ansItem.scale;
                            element.scaleY = ansItem.scale
                        }
                        if (ansItem.rotation) {
                            element.rotation = ansItem.rotation;
                        }
                        element.pivotX = element.width / 2;
                        element.pivotY = element.height / 2;
                        element.isSelect = true;
                        // 可能需要旋转角度
                        element.rotation = curBox.rotation||ansItem.rotation||'';
                        curBox.target.addChild(element);
                        if (curBox.target.hasCn) {
                            // 记录已经填入多少个选项
                            curBox.target.hasCn++;
                        } else {
                            curBox.target.hasCn = 1;
                        }
                        ++this.number;
                        ++this.selectNum;
                        ++this.fillNum;
                        this.gameAction('right')
                    }

                }
                this.moveTarget = null;

            });
            // 初始化移动事件
            this.scenes.on(Laya.Event.MOUSE_MOVE, this, (e) => {
                if (this.isDown && this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let x = e.stageX;
                    let y = e.stageY;
                    element.x = x-this.sumX;
                    element.y = y-this.sumY;
                    
                }
            });
        });
    }

    clearGame() {
        this.gameOver = false;
        this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    onCheckBoxClick(e) {
        if(this.maxAns === this.fillNum) {
            this.gameOver = true;
            this.gameAction('success');
        } else {
            shakeJoggle(e.target)
        }
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




}
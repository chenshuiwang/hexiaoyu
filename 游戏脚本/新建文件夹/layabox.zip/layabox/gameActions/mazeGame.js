/**
 * 
 *  迷宫游戏交互
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight,removeRight,countdown ,removeCountdown, addGlowFilter} from '../util/gameActions'

export default class SortGame{
    constructor() { 
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 1
    }

    init({scenes,AnsArr,boxArr,maxAns}) {
        this.AnsArr = AnsArr;//点击元素的的数组
        this.boxArr = boxArr;//需要移动的元素的数组
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initClick();
    }


    initClick() {
        this.AnsArr.forEach((element) => {
            if(typeof(element.target) === 'object'){
                element.target.on(Laya.Event.CLICK,this,this.clickHandle);
            }else{
                element.on(Laya.Event.CLICK,this,this.clickHandle);
            }
        });
    }

    clickHandle(e) {
        let box = e.target;
        if (box.hasRight) {
            return;
        }
        let index = this.AnsArr.findIndex(v => {
            if(typeof(v.target) === 'object'){
                return box === v.target
            }else{
                return box === v
            }
        })
        if (++index == this.selectNum) {
            this.onCorrectClick(e);
        } else {
            this.onErrorClick(e);
        }

    }

    //错误效果
    onErrorClick(e) {
        if (this.gameOver) {
            return;
        }
        e.stopPropagation();
        shakeJoggle(e.target)
    }

    //正确
    onCorrectClick(e) {
        if (this.gameOver) {
            return;
        }
        e.target.hasRight = true;
        addGlowFilter(e.target);
        let index = this.AnsArr.findIndex(v => v.target == e.target);
        if(index < 0){
            index = this.AnsArr.findIndex(v => v == e.target);
        }
        if(typeof(this.AnsArr[index].target) === 'object'){
            this.boxArr[0].x = this.AnsArr[index].position.x;
            this.boxArr[0].y = this.AnsArr[index].position.y
        }else{
            console.log(index)
            console.log(this.AnsArr[index])
            this.boxArr[0].x = this.AnsArr[index].x;
            this.boxArr[0].y = this.AnsArr[index].y
        }
        ++this.selectNum;
        if (this.selectNum > this.maxAns) {
            this.gameOver = true;
            removeCountdown(this.view_middle);
            this.gameAction('success');
        }   
    }



    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            parmas.second = this.second - this.view_middle._second
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }

}
/**
 * 
 *  拼图拖动
 * 1.每个盒子有可填入数量，数量0为不可填入
 * 2.填入后的选项可以设置角度
 * 3.拼图重叠规则 居中遮盖
 * 4.在空白处释放选项，恢复原样，不算错误
 * 5.填错盒子，或者盒子已满，算1次错误
 * 6.成功填入正确盒子，算一次正确
 * 7.所有盒子的可填数量已经全部填入完毕  为游戏成功
 * 
 **/ 

/**
 *boxArr:[
        {
            target: this.box1,//盒子对象
            fillNum: 1,//可填入数量
            key: 1,//用来匹配是否可填
            rotation: 150,  //旋转角度   
        },
    ]
 * AnsArr:[
        {
            target: this.b1,//选项对象
            key:1,    //用来匹配盒子
            rotation: 0,  //旋转角度
        },
    ]
 *
 * @export
 * @class MoveFillGame
 */
export default class MoveFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.gameOver = false;
        this.number = 1;// number用于记录当前那个元素可以拖动，用于依次拖动的游戏
        this.addedArr = [];
    }

    init({scenes,boxArr,AnsArr,maxAns,AnspositionArr}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.AnspositionArr = AnspositionArr;// 从多个答案中选择两个以上到同一个目标中，用于存储答案的位置数组
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initMove();
    }


    initMove() {
        this.AnsArr.forEach(ansItem => {
            let element = ansItem.target
            // 记录初始状态
            element.preX = element.x;
            element.preY = element.y;
            element.preZ = element.zOrder;
            // 初始化点击开始
            element.on(Laya.Event.MOUSE_DOWN, this, (e) => {
                if (element.isSelect) {
                    return
                }
                this.isDown = true;
                this.moveTarget = element;
                this.sumX = e.stageX - element.x;
                this.sumY = e.stageY - element.y;
                element.zOrder = 99;
            });
            // 初始化离开事件
            element.on(Laya.Event.MOUSE_UP, this, (e) => {
                
                this.isDown = false;
                if (this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    // let mouseX,mouseY;
                    // if(element.rotation){
                    //     console.log(23133)
                    //     let preR = element.rotation;
                    //     element.rotation = 0;
                    //     mouseX = element.x+element.width/2;
                    //     mouseY = element.y+element.height/2;
                    //     element.rotation = preR;
                    // }else{
                    //     mouseX = element.x+element.width/2;
                    //     mouseY = element.y+element.height/2;
                    // }
                    let mouseX,mouseY;
                    if(element && element.rotation){
                        element.rotation = element.rotation % 360;
                        let tan = 90 - Math.atan(element.width/element.height) / (Math.PI / 180);
                        let r = Math.sqrt(Math.pow(element.width,2) + Math.pow(element.height,2));
                        console.log(r)
                        if((0 > element.rotation　&& element.rotation > -90) || (270 < element.rotation　&& element.rotation > 360)){
                            mouseX = element.x + Math.sin(tan*Math.PI/180) * r /2;
                            mouseY = element.y - Math.cos(tan*Math.PI/180) * r /2;
                        }else if((-270 > element.rotation　&& element.rotation > -360)){
                            mouseX = element.x + Math.sin(tan*Math.PI/180) * r / 2;
                            mouseY = element.y - Math.cos(tan*Math.PI/180) * r / 2;
                        }else if((-180 > element.rotation　&& element.rotation > -270)){
                            mouseX = element.x - Math.sin(tan*Math.PI/180) * r / 2;
                            mouseY = element.y - Math.cos(tan*Math.PI/180) * r /2;
                        }else if((180 < element.rotation　&& element.rotation < 270) || (-90 > element.rotation　&& element.rotation > -180)){
                            mouseX = element.x + Math.sin(tan*Math.PI/180) * r /2 ;
                            mouseY = element.y -  Math.cos(tan*Math.PI/180) * r/2;
                        }else if((90 < element.rotation　&& element.rotation < 180)||(0 < element.rotation　&& element.rotation < 90)){
                            mouseX = element.x - Math.sin(tan*Math.PI/180) * r / 2;
                            mouseY = element.y - Math.cos(tan*Math.PI/180) * r /2;
                        }
                        // console.log(mouseX,element.x);
                        // let box = new Laya.Box();
                        // box.x = mouseX;
                        // box.y = mouseY;
                        // box.bgColor = 'red'
                        // box.width = 30;
                        // box.height = 30;
                        // box.zOrder = 10;
                        // this.scenes.view_middle.addChild(box);
                    }else{
                        mouseX = element.x+element.width/2;
                        mouseY = element.y+element.height/2;
                    }
                    // let mouseX = element.x+element.width/2;
                    // let mouseY = element.y+element.height/2;
                    // 判断是否在盒子区释放选项
                    let curBox = this.boxArr.find((boxItem) => {
                        let boxTarget = boxItem.target;
                        if (!boxTarget) {
                            return;
                        }
                        // console.log('mouseX:',mouseX,'boxTarget.x:',boxTarget.x,'boxTarget.width:',boxTarget.width)
                        // console.log('mousey:',mouseY,'boxTarget.y:',boxTarget.y,'boxTarget.width:',boxTarget.height)
                        let inX = mouseX >= boxTarget.x && mouseX <= boxTarget.x + boxTarget.width;
                        let inY = mouseY >= boxTarget.y && mouseY <= boxTarget.y + boxTarget.height;
                        let inKey = ansItem.key === boxItem.key;
                        let hasCn = boxItem.target.hasCn && boxItem.fillNum <= boxItem.target.hasCn;
                        // console.log('inX:', inX, 'inY:', inY, 'inKey:', inKey, 'hasCn:', hasCn);
                        return inX && inY && inKey && !hasCn;
                    })
                    // 重置zOrder
                    element.zOrder = element.preZ;

                    //在空白处放置就还原
                    if(!curBox) {
                        element.x = element.preX;
                        element.y = element.preY;
                        return;
                    }

                    //判断盒子是否存在key值
                    if(!curBox.key){
                        // 如果key为零或不传，那么就还原
                        if(!ansItem.key){
                            element.x = element.preX;
                            element.y = element.preY;
                            return;
                        }
                        let index = this.boxArr.findIndex(v => JSON.stringify(v.key) == JSON.stringify(ansItem.key));
                        if(index < 0){
                            if(ansItem.key instanceof Array) {
                                let keyAnsArr  = this.boxArr.filter(v => v.key && v.target != curBox.target);
                                if(keyAnsArr.length > 0){
                                    keyAnsArr.forEach(v => {
                                        let s = [...new Set([...ansItem.key,...v.key])];
                                        console.log('s的长度',s)
                                        let maxLength = ansItem.key.length > v.key.length ? ansItem.key.length : v.key.length
                                        if(s.length === maxLength){
                                            element.x = element.preX;
                                            element.y = element.preY;
                                            return;
                                        }else if(s.length > maxLength && s.length < v.key.length + ansItem.key.length){
                                            // curBox.commonKey = s.filter(v2 => {
                                            //     let index1 = ansItem.key.findIndex(v3 => v3 === v2);
                                            //     let index2 = v.key.findIndex(v3 => v3 === v2);
                                            //     return index1 === -1 || index2 === -1; 
                                            // })
                                            curBox.commonKey = []
                                            ansItem.key.forEach((v2,i) => {
                                                if(v2 === ansItem.key[i]){
                                                    curBox.commonKey.push(v2)
                                                }
                                            })
                                            curBox.commonKey.forEach((v2,i) => {
                                                keyAnsArr.forEach(v3 => {
                                                    if(v3.commonKey){
                                                        v3.commonKey.forEach(v4 => {
                                                            if(v4 === v2){
                                                                curBox.commonKey.splice(i,1)
                                                            }
                                                        })
                                                    }
                                                })
                                            })
                                            console.log('这是key',curBox.commonKey)
                                            let i = this.boxArr.findIndex(val => val === curBox);
                                            console.log('设置了key值',this.boxArr[i].fillNum)
                                            
                                        }
                                    })
                                }
                            }
                            curBox.key = ansItem.key;
                        }else{
                            element.x = element.preX;
                            element.y = element.preY;
                            return;
                        }
                    }else{
                        if(ansItem.key instanceof Array) {
                            let index;
                            if(curBox.commonKey){
                                console.log("有关键字",curBox.commonKey,ansItem.key)
                                curBox.commonKey.forEach(v => {
                                    if(index > -1){
                                        return;
                                    }
                                    index = ansItem.key.findIndex(vv => v === vv);
                                    console.log('index的值为',index)
                                    if(index > -1) {
                                        console.log('为什么');
                                        return;
                                    }
                                })
                                if(index === -1){
                                    console.log(curBox.commonKey)
                                    console.log("这是-1")
                                    element.x = element.preX;
                                    element.y = element.preY;
                                    return;
                                }
                                let isWrong = false;
                                this.boxArr.forEach(v => {
                                    if(v.target != curBox.target){
                                        if(v.key){
                                            let k = [...new Set([...v.key,...ansItem.key])].length;
                                            let maxLength = ansItem.key.length > v.key.length ? ansItem.key.length : v.key.length
                                            console.log("k的值为",k)
                                            if(k === maxLength){
                                                isWrong = true;
                                                return;
                                            }
                                        }
                                    }
                                })
                                if(isWrong){
                                    element.x = element.preX;
                                    element.y = element.preY;
                                    return;
                                }
                            }else{
                                let isWrong = false;
                                this.boxArr.forEach(v => {
                                    if(v.target != curBox.target){
                                        if(v.key){
                                            let k = [...new Set([...v.key,...ansItem.key])].length;
                                            let maxLength = ansItem.key.length > v.key.length ? ansItem.key.length : v.key.length
                                            console.log("k的值为",k)
                                            if(k === maxLength){
                                                isWrong = true;
                                                return;
                                            }
                                        }
                                    }
                                })
                                if(isWrong){
                                    if(JSON.stringify(ansItem.key) != JSON.stringify(curBox.key)){
                                        element.x = element.preX;
                                        element.y = element.preY;
                                        return;
                                    }
                                }
                            }
                            let s = [...new Set([...ansItem.key,...curBox.key])];
                            let maxLength = ansItem.key.length > curBox.key.length ? ansItem.key.length : curBox.key.length
                            if(s.lenth === ansItem.key.length + curBox.key.length){
                                element.x = element.preX;
                                element.y = element.preY;
                                return;
                            }else if(s.length > maxLength && s.length < curBox.key.length + ansItem.key.length){
                                // curBox.commonKey = s.filter(v2 => {
                                //     let index1 = ansItem.key.findIndex(v3 => v3 === v2);
                                //     let index2 = curBox.key.findIndex(v3 => v3 === v2);
                                //     return index1 === -1 || index2 === -1; 
                                // })

                                let ind = this.boxArr.findIndex(v => v === curBox)
                                this.boxArr[ind].commonKey = []
                                ansItem.key.forEach(v2 => {
                                    curBox.key.forEach(v3 => {
                                        if(v2 === v3){
                                            curBox.commonKey.push(v2)
                                        }
                                    })
                                })
                            }
                        }
                    }
                    //判断盒子时候存在fillNum
                    if(!curBox.fillNum){
                        let fillNum = 0;
                        this.AnsArr.forEach(vv => {
                            if(vv.key === curBox.key){
                                fillNum++;
                            }
                        })
                        this.boxArr.forEach(v => {
                            if(ansItem.key instanceof Array){
                                if(!v.fillNum){
                                    v.fillNum = this.AnsArr.length;
                                }
                            }else if(v.target === curBox.target){
                                v.fillNum = fillNum;
                            }
                        })
                        
                    }
                    if(((curBox.key != ansItem.key && JSON.stringify(curBox.key) != JSON.stringify(ansItem.key)) || !curBox.fillNum || (curBox.target.hasCn && curBox.fillNum <= curBox.target.hasCn)) && !curBox.commonKey) {
                        // 放错盒子提示错误
                        console.log('???')
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    } else if(ansItem.number&&ansItem.number != this.number){
                        // 不按顺序拖动
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    }else {
                        // 将选项填入盒子
                        if(ansItem.position){
                            element.centerX = ansItem.position.centerX||0;
                            element.centerY = ansItem.position.centerY||0;
                        }else{
                            if (curBox.position&&curBox.position.auto) {
                                element.centerX = curBox.position.arr[this.addedArr.length].centerX;
                                element.centerY = curBox.position.arr[this.addedArr.length].centerY;
                                this.addedArr.push(element);
                            } else {
                                element.centerX = 0;
                                element.centerY = 0;
                            }
                        }
                        //变换位置
                        if(this.AnspositionArr){
                            let i = curBox.target.hasCn||0;
                            if(ansItem.key instanceof Array){
                                console.log(curBox.fillNum)
                                element.centerX = this.AnspositionArr[i].centerX||0;
                                element.centerY = this.AnspositionArr[i].centerY||0;
                            }
                            let index = this.AnspositionArr.findIndex(v => v.key === curBox.key);
                            if(index < 0 ){
                                element.centerX = this.AnspositionArr[i].centerX||0;
                                element.centerY = this.AnspositionArr[i].centerY||0;
                            }else{
                                element.centerX = this.AnspositionArr[index].arr[i].centerX||0;
                                element.centerY = this.AnspositionArr[index].arr[i].centerY||0;
                            }
                        }
                        if(ansItem.scale){
                            element.scaleX = ansItem.scale;
                            element.scaleY = ansItem.scale
                        }
                        if(ansItem.rotation){
                            element.rotation = ansItem.rotation;
                        }
                        element.pivotX = element.width / 2;
                        element.pivotY = element.height / 2;
                        element.isSelect = true;
                        // 可能需要旋转角度
                        element.rotation = curBox.rotation||ansItem.rotation||'';
                        curBox.target.addChild(element);
                        if (curBox.target.hasCn) {
                            // 记录已经填入多少个选项
                            curBox.target.hasCn++;
                        } else {
                            curBox.target.hasCn = 1;
                        }
                        ++this.number;
                        ++this.selectNum;
                        if(ansItem.key instanceof Array) {
                            if(!this.count){
                                this.count = 0
                            }
                            this.count++;
                            if(this.count === this.AnsArr.length){
                                this.gameAction('success')
                            }
                        }
                        this.gameAction('right')


                        // 筛选是否还有盒子没填
                        let needFill = this.boxArr.filter((boxItem) => {
                            let boxTarget = boxItem.target;
                            if(!boxItem.fillNum){
                                return boxItem
                            }
                            return boxItem.fillNum && (!boxTarget.hasCn || boxItem.fillNum > boxTarget.hasCn)
                        })

                        // 判断是否所有盒子都已成功填入所有选项
                        if (!needFill.length) {
                            this.gameAction('success')
                        }
                    }

                }
                this.moveTarget = null;

            });
            // 初始化移动事件
            this.scenes.on(Laya.Event.MOUSE_MOVE, this, (e) => {
                if (this.isDown && this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let x = e.stageX;
                    let y = e.stageY;
                    element.x = x-this.sumX;
                    element.y = y-this.sumY;
                    
                }
            });
        });
    }



    clearGame() {
        this.gameOver = false;
        this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




}


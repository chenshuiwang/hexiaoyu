/**
 * 
 *  剪切拖动旋转游戏
 * 1.每个盒子有可填入数量，数量0为不可填入
 * 2.填入后的选项可以设置角度
 * 3.拼图重叠规则 居中遮盖
 * 4.在空白处释放选项，恢复原样，不算错误
 * 5.填错盒子，或者盒子已满，算1次错误
 * 6.成功填入正确盒子，算一次正确
 * 7.所有盒子的可填数量已经全部填入完毕  为游戏成功
 * 
 **/ 

/**
 *boxArr:[
        {
            target: this.box1,//盒子对象
            fillNum: 1,//可填入数量
            key: 1,//用来匹配是否可填
            rotation: 150,  //旋转角度   
        },
    ]
 * AnsArr:[
        {
            target: this.b1,//选项对象
            key:1,    //用来匹配盒子
            rotation: 0,  //旋转角度
        },
    ]
 *
 * @export
 * @class MoveFillGame
 */
import { shakeJoggle, addGlowFilter ,removeGlowFilter} from '../util/gameActions'

export default class MoveFillGame{
    constructor() { 
        this.curAns = null;
        this.curBox = null;
        this.curPoint = null;
        this.gameOver = false;
        this.number = 1;// number用于记录当前那个元素可以拖动，用于依次拖动的游戏
    }

    init({scenes,boxArr,AnsArr,maxAns,AnspositionArr,pointArr,cutPicArr,spinArr,spinRotation,lineArr}) {
        this.AnsArr = AnsArr;
        this.boxArr = boxArr;
        this.AnspositionArr = AnspositionArr;// 从多个答案中选择两个以上到同一个目标中，用于存储答案的位置数组
        this.pointArr = pointArr;// 点数组，点击对图形进行切割
        this.cutPicArr = cutPicArr;// 要切割的图片数组
        this.spinArr = spinArr;// 旋转按钮数组
        this.spinRotation = spinRotation; // 旋转一次的角度,
        this.lineArr = lineArr;// 线数组
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initVisible();
        this.initClick();
        this.initMove();
    }

    //点击初始化
    initClick() {
        this.pointArr.forEach(e => {
            this.pointArr.forEach(element => {
                element.target.on(Laya.Event.CLICK,this,this.onPointClick);
            });
        })
        this.spinArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.onSpinClick);
        });
        this.AnsArr.forEach(element => {
            element.target.on(Laya.Event.CLICK,this,this.onAnsClick);
        });
    }

    //初始化元素是否可见
    initVisible() {
        this.AnsArr.forEach(v => v.target.visible = false);
        if(this.lineArr) {
            this.lineArr.forEach(v => v.target.visible = false)
        }
    }

    //拖动初始化
    initMove() {
        if(!this.curAns || (this.curAns && !this.curAns.isMove)){
            return;
        }
        
        this.AnsArr.forEach(ansItem => {
            let element = ansItem.target;
            // 记录初始状态
            element.preX = element.x;
            element.preY = element.y;
            element.preZ = element.zOrder;
            element.preR = element.rotation;

            
            // 初始化点击开始
            element.on(Laya.Event.MOUSE_DOWN, this, (e) => {
                if (element.isSelect) {
                    return
                }
                if(!element.isMove){
                    return;
                }
                this.curAns.isMoving = true;
                this.isDown = true;
                this.moveTarget = element;
                this.sumX = e.stageX - element.x;
                this.sumY = e.stageY - element.y;
                element.zOrder = 99;
            });
            // 初始化离开事件
            element.on(Laya.Event.MOUSE_UP, this, (e) => {
                this.isDown = false;
                if (this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let mouseX = element.x;
                    let mouseY = element.y;
                    // 判断是否在盒子区释放选项
                    let curBox = this.boxArr.find((boxItem) => {
                        let boxTarget = boxItem.target;
                        if (!boxTarget) {
                            return;
                        }
                        let inX = mouseX >= boxTarget.x && mouseX <= boxTarget.x + boxTarget.width;
                        let inY = mouseY >= boxTarget.y && mouseY <= boxTarget.y + boxTarget.height;
                        let inKey = ansItem.key === boxItem.key;
                        let hasCn = boxItem.target.hasCn && boxItem.fillNum <= boxItem.target.hasCn;
                        if(boxItem.otherAnsArr && !inKey) {
                            inKey = true;
                        }
                        // console.log('inX:', inX, 'inY:', inY, 'inKey:', inKey, 'hasCn:', hasCn);
                        if(!inKey) {
                            //console.log('inKey',inKey,boxItem.otherRotation)
                            this.boxArr.forEach(vv => {
                                if(vv.otherRotation) {
                                    vv.otherRotation.forEach(v => {
                                        if(v === this.curAns.rotation){
                                            inKey = true;
                                        }
                                    })
                                }
                            })
                        }
                        return inX && inY && inKey && !hasCn;
                    })
                    // 重置zOrder
                    element.zOrder = element.preZ;
                    // 当前选择元素的索引
                    let ansIndex, otherRoIndex, isEqual, box;
                    if(curBox){
                        if(curBox.key != ansItem.key){
                            console.log('经过了这里')
                            if(curBox.otherAnsArr) {
                                box = curBox.otherAnsArr.find( v => v.key === ansItem.key);
                                if(box.rotation === this.curAns.rotation % 360) {
                                    otherRoIndex = 1
                                }else {
                                    otherRoIndex = -1
                                }
                            }else {
                                otherRoIndex = curBox.otherRotation.findIndex(v => v === this.curAns.rotation % 360);
                            }
                        }
                        ansIndex = this.boxArr.findIndex(v => v.target === curBox.target);
                        console.log(this.curAns.rotation,ansIndex,otherRoIndex)
                        isEqual = (curBox.key === ansItem.key);
                        if(this.boxArr.length === 1) {
                            otherRoIndex = curBox.rotation.findIndex(v => this.curAns.rotation % 360 === v);
                            if(otherRoIndex > 1) {
                                curBox.rotation.splice(otherRoIndex,1)
                                curBox.rotation = [curBox.rotation[2]]
                            }else if (otherRoIndex >　-1) {
                                curBox.rotation.splice(otherRoIndex,1)
                                curBox.rotation = [curBox.rotation[0]]
                            }
                        }
                    }
                    if(curBox && !curBox.otherRotation && !curBox.otherAnsArr && this.boxArr.length > 1){
                        otherRoIndex = -1;
                    }
                    if (!otherRoIndex && otherRoIndex != 0) {
                        otherRoIndex = -1;
                    }
                    console.log('otherRoIndex',otherRoIndex)
                    if (!curBox) {
                        // 在空白处释放则还原
                        console.log('空白',this.curAns.rotation)
                        element.x = element.preX;
                        element.y = element.preY;
                        return;
                    } else if((curBox.key != ansItem.key &&　otherRoIndex < 0) || !curBox.fillNum || (curBox.target.hasCn && curBox.fillNum <= curBox.target.hasCn)) {
                        // 放错盒子提示错误
                        console.log('错误',otherRoIndex)
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong');
                        return;
                    } else if(ansItem.number && ansItem.number != this.number){
                        // 不按顺序拖动
                        console.log('顺序')
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    }else if ((this.curAns.rotation % 360 != this.boxArr[ansIndex].rotation) &&　(otherRoIndex === -1)){
                        // 元素旋转的角度不对
                        console.log('jiaodubudui',)
                        element.x = element.preX;
                        element.y = element.preY;
                        this.gameAction('wrong')
                        return;
                    }else {
                        // 将选项填入盒子
                        if(ansItem.position ){
                            element.centerX = ansItem.position.centerX||0;
                            element.centerY = ansItem.position.centerY||0;
                        }else{
                            if (curBox.position&&curBox.position.auto) {
                                element.centerX = curBox.position.arr[this.addedArr.length].centerX;
                                element.centerY = curBox.position.arr[this.addedArr.length].centerY;
                                this.addedArr.push(element);
                            } else {
                                element.centerX = 0;
                                element.centerY = 0;
                            }
                        }

                        if(box && box.position) {
                            element.centerX = box.position.centerX||0;
                            element.centerY = box.position.centerY||0;
                        }

                        if(ansItem.scale){
                            element.scaleX = ansItem.scale;
                            element.scaleY = ansItem.scale
                        }
                        // if(ansItem.rotation){
                        //     element.rotation = ansItem.rotation;
                        // }
                        element.rotation = this.curAns.rotation;
                        element.pivotX = element.width / 2;
                        element.pivotY = element.height / 2;
                        element.isSelect = true;
                        ansItem.target.isSelect = true;
                        // 可能需要旋转角度
                        //element.rotation = curBox.rotation||ansItem.rotation||'';
                        curBox.target.addChild(element);
                        if (curBox.target.hasCn) {
                            // 记录已经填入多少个选项
                            curBox.target.hasCn++;
                        } else {
                            curBox.target.hasCn = 1;
                        }
                        ++this.number;
                        ++this.selectNum;
                        element.isFill = true;
                        // this.curAns = null;
                        this.gameAction('right')

                        // 筛选是否还有盒子没填
                        let needFill = this.boxArr.filter((boxItem) => {
                            let boxTarget = boxItem.target;
                            return boxItem.fillNum && (!boxTarget.hasCn || boxItem.fillNum > boxTarget.hasCn)
                        })

                        // 判断是否所有盒子都已成功填入所有选项
                        if (!needFill.length) {
                            this.gameAction('success')
                        }
                    }

                }
                this.moveTarget = null;

            });
            // 初始化移动事件
            this.scenes.on(Laya.Event.MOUSE_MOVE, this, (e) => {
                if (this.isDown && this.moveTarget == element) {
                    if (element.isSelect) {
                        return
                    }
                    let x = e.stageX;
                    let y = e.stageY;
                    element.x = x-this.sumX;
                    element.y = y-this.sumY;
                    
                }
            });
        });
    }

    // 旋转按钮点击事件
    onSpinClick() {
        if(this.curAns){
            let index = this.AnsArr.findIndex(v => v.target === this.curAns);
            if(this.curAns.isSelect){
                return;
            }
            this.curAns.pivotX = this.curAns.width / 2;
            this.curAns.pivotY = this.curAns.height / 2;
            if(this.spinRotation) {
                this.curAns.rotation += this.spinRotation;
            }else {
                this.curAns.rotation += 90;
            }
            if(this.curAns.rotation > 359)　{
                this.curAns.rotation %= 360;
            }
        }
    }

    // 切割点的点击事件
    onPointClick(e) {
        if(this.curPoint){
            let index1 = this.pointArr.findIndex(v => v.target === this.curPoint);
            let index2 = this.pointArr.findIndex(v => v.target === e.target);
            if(this.pointArr[index1].key === this.pointArr[index2].key &&　index1 != index2){
                addGlowFilter(e.target);
                this.gameAction('right');
                if(this.AnsArr.length === 4){
                    if(this.number === 1) {
                        this.lineArr.forEach( v => {
                            if(v.key === this.pointArr[index1].key) {
                                v.target.visible = true;
                            }
                        })
                        this.number++;
                        this.curPoint = null;
                        return;
                    }else {
                        this.lineArr.forEach( v => {
                            if(v.key === this.pointArr[index1].key) {
                                v.target.visible = true;
                            }
                        })
                    }
                }
                setTimeout(() => {
                    this.pointArr.forEach(v => v.target.visible = false);
                    this.AnsArr.forEach(v => v.target.visible = true)
                    this.cutPicArr.forEach(v => v.visible = false)
                    if(this.lineArr) {
                        this.lineArr.forEach(v => v.target.visible = false)
                    }
                }, 1000);
            }else{
                this.gameAction('wrong');
                shakeJoggle(this.curPoint);
                removeGlowFilter(this.curPoint);
                this.curPoint = null;
            }
        }else{
            this.pointArr.forEach(v => removeGlowFilter(v.target));
            this.curPoint = e.target;
            addGlowFilter(this.curPoint)
        }
    }

    // 答案点击事件
    onAnsClick(e) {
        if(e.target.isFill){
            removeGlowFilter(this.curAns);
            return;
        }
        if(this.curAns){
            let index = this.AnsArr.findIndex(v => v.target === this.curAns);
            this.AnsArr[index].target.isMove = false;
            removeGlowFilter(this.curAns);
            this.curAns = null;
        }
        e.target.isMove = true;
        this.curAns = e.target;
        addGlowFilter(this.curAns);
        this.initMove()
    }

    clearGame() {
        this.gameOver = false;
        // this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 答案点击事件

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }
}

/**
 * 
 *  多音频游戏交互（选择游戏）
 * 
 **/ 
import { addSelect, removeSelect, shakeJoggle, addRight } from '../util/gameActions'
let audioBgStop = "https://img.qlchat.com/qlLive/activity/image/MRBYOO25-CJR6-AQGZ-1583224359908-D23JZJQ97MB4.png";
let audioBgPlay = "https://img.qlchat.com/qlLive/activity/image/RFBLQ3VA-8YLS-S3PP-1583224365636-6RJ2D4PZAHIV.png";
export default class mutiplayerGame{
    constructor() { 
        this.curCar = null;
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 0;
        this.index = 0;
        this.trumpetArr = []
    }

    init({scenes,boxArr,AnsArr,objArr,maxAns}) {
        this.boxArr = boxArr;
        this.AnsArr = AnsArr;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns||AnsArr.length;
        this.initPlay(objArr); // objArr是一个对象数组，用于存储音频对象的属性
        this.initClick();
    }


    initClick() {
        this.boxArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.onErrorClick);
        });
        this.AnsArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.onCorrectClick);
        });
    }
    initPlay(objArr){
        objArr.forEach((v,i) => {
            this.initPlayer({
                viewMiddle:this.scenes.view_middle,
                url:v.url,
                position:v,
                index:i
            });
        })
    }
    //错误效果
    onErrorClick(e) {
        if (this.gameOver) {
            return;
        }
        e.stopPropagation();
        shakeJoggle(e.target)
        this.gameAction('wrong');
    }

    //正确
    onCorrectClick(e) {
        if (this.gameOver||e.target.isSelect) {
            return;
        }
        e.target.isSelect = true;
        this.gameAction('right');
        
        ++this.selectNum;
        addSelect(e.target)
        addRight(e.target)
        if (this.selectNum >= this.maxAns) {
            this.gameOver = true;
            this.gameAction('success')
        }   
    }



    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
        console.log(`游戏${type}`);
    }

    
    //*****************************音频**********************************************************************
    initPlayer({ url, viewMiddle, position,index }) {
        if (!viewMiddle) {
            return;
        }
        let trumpt = new Laya.Image();
        trumpt.width = 63;
        trumpt.height = 46;
        trumpt.zOrder = 10;
        trumpt.left = position.left;
        trumpt.bottom = position.bottom;
        trumpt.url = url;
        this.trumpetArr.push(trumpt)
        this.handleEnded(index);
        viewMiddle.addChild(trumpt);

        trumpt.on(Laya.Event.CLICK, this, (e) => {this.playTitleSound(index)});
    }
   
    handleEnded(index){
        this.isPlaying = false;
        this.trumpetArr[index].audioAni&&Laya.timer.clear(this, this.trumpetArr[index].audioAni);
        this.trumpetArr[index].skin = audioBgStop;
    }

    // 播放题目声音
    playTitleSound(index) {
        Laya.SoundManager.stopAllSound();
        // 允许重复播放
        if (this.isPlaying) {
            Laya.SoundManager.stopSound(this.url);
            this.trumpetArr[index].audioAni&&Laya.timer.clear(this, this.trumpetArr[index].audioAni);
        }
        this.isPlaying = true;
        this.trumpetArr[index].skin = audioBgPlay;
        Laya.SoundManager.playSound(this.trumpetArr[index].url, 1, new Laya.Handler(this, (e) => {this.handleEnded(index)}));
        

        // 音频动画
        this.trumpetArr[index].audioAni = (e) => {
            if (this.trumpetArr[index].skin== audioBgStop) {
                this.trumpetArr[index].skin = audioBgPlay;

            } else {
                this.trumpetArr[index].skin = audioBgStop;
            }
        }
        Laya.timer.frameLoop(20, this, this.trumpetArr[index].audioAni);
    }

}
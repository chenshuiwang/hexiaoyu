/**
 * 
 *  点连成线游戏交互
 * 
 **/ 
import { shakeJoggle, addGlowFilter ,removeGlowFilter} from '../util/gameActions'

export default class MoveFillGame{
    constructor() { 
        this.curPoint = null;
        this.gameOver = false;
        this.linesNum = 0
    }

    init({scenes,pointArr,lineArr,maxAns,type}) {
        this.pointArr = pointArr;// 点数组，点击对图形进行切割
        this.lineArr = lineArr;// 线数组
        this.type = type;// 游戏类型，值为“changeRed”代表点击黑点变成红色
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.maxAns = maxAns;
        this.initVisible();
        this.initClick();
    }

    //点击初始化
    initClick() {
        this.pointArr.forEach(element => {
            element.target.on(Laya.Event.CLICK,this,this.onPointClick);
        });
    }

    //初始化元素是否可见
    initVisible() {
        this.lineArr.forEach(v => v.target.visible = false);
    }

    // 切割点的点击事件
    onPointClick(e) {
        if(this.curPoint){
            let index1 = this.pointArr.findIndex(v => v.target === this.curPoint);
            let index2 = this.pointArr.findIndex(v => v.target === e.target);
            if(this.pointArr[index1].key === this.pointArr[index2].key &&　index1 != index2){
                addGlowFilter(e.target);
                if (this.type === 'changeRed') {
                    this.curPoint._children.forEach(v => {
                        if( v.name === 'black') {
                            v.visible = true
                        }
                    })
                }
                this.lineArr.forEach(v => {
                    if (v.key === this.pointArr[index1].key) {
                        v.target.visible = true;
                    }
                })
                this.linesNum++;
                this.gameAction('right');
                if (this.linesNum === this.lineArr.length) {
                    setTimeout(() => {
                        this.gameOver = true;
                        this.gameAction('success')
                    }, 1000);
                }
                this.curPoint = null;
            }else{
                this.gameAction('wrong');
                shakeJoggle(this.curPoint);
                removeGlowFilter(this.curPoint);
                if (this.type === 'changeRed') {
                    this.curPoint._children.forEach(v => {
                        if( v.name === 'black') {
                            v.visible = true
                        }
                    })
                }
                this.curPoint = null;
            }
        }else{
            this.pointArr.forEach(v => removeGlowFilter(v.target));
            this.curPoint = e.target;
            addGlowFilter(this.curPoint);
            if (this.type === 'changeRed') {
                this.curPoint._children.forEach(v => {
                    if( v.name === 'black') {
                        v.visible = false
                    }
                })
            }
        }
    }

    // 答案点击事件
    onAnsClick(e) {
        if(e.target.isFill){
            removeGlowFilter(this.curAns);
            return;
        }
        if(this.curAns){
            let index = this.AnsArr.findIndex(v => v.target === this.curAns);
            this.AnsArr[index].target.isMove = false;
            removeGlowFilter(this.curAns);
            this.curAns = null;
        }
        e.target.isMove = true;
        this.curAns = e.target;
        addGlowFilter(this.curAns);
        this.initMove()
    }

    clearGame() {
        this.gameOver = false;
        // this.initMove();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 答案点击事件

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }
}

// /**
//  * 
//  *  数数游戏交互
//  * 
//  **/ 

import { addSelect, removeSelect, shakeJoggle, addRight,removeRight,countdown ,removeCountdown} from '../util/gameActions'

export default class countGame{
    constructor() { 
        this.curBox = null;
        this.gameOver = false;
        this.selectNum = 1;
        this.number = 0;
    }

    //初始化
    init({scenes,AnsArr,boxArr,color,length,numberTop,isSort=true}) {
        this.AnsArr = AnsArr;
        this.curBox = boxArr;
        this.color = color;
        this.view_middle = scenes.view_middle;
        this.scenes = scenes;
        this.numberTop = numberTop||10;
        this.isSort = isSort;
        if(!length){
            this.maxAns = AnsArr.length;
        }else{
            this.maxAns = length
        }
        this.initClick();
        this.initBoxText()
    }


    initClick() {
        this.AnsArr.forEach(element => {
            element.on(Laya.Event.CLICK,this,this.clickHandle);
        });
    }

    clickHandle(e) {
        let box = e.target;
        if (box.hasRight) {
            return;
        }
        if (( !this.isSort && box.name ) || (this.isSort && box.name == this.selectNum)) {
            this.onCorrectClick(e);
        } else {
            this.onErrorClick(e);
            this.clearAllSelect();
            this.number = 0;
            this.changePic()
            }

    }
    initCountdown() {
        removeCountdown(this.view_middle)
        countdown(this.view_middle, this.second, () => {
            this.initCountdown();
            this.clearAllSelect()
        })
    }

    //初始化数字
    initBoxText(){
        let num = new Laya.TextArea()
        num.centerX = 0;
        num.right = 150;
        num.top = this.numberTop;
        num.zOrder = 6;
        num.fontSize = 150;
        num.color = this.color||'red';
        num.text = "0";
        num.align = 'center';
        this.numBox = num;
        this.scenes.view_middle.addChild(this.numBox);
    }

    clearAllSelect() {
        this.selectNum = 1
        this.AnsArr.forEach(element => {
            element.hasRight = false;
            removeSelect(element);
            removeRight(element);
        });
        
    }

    //错误效果
    onErrorClick(e) {

        e.stopPropagation();
        shakeJoggle(e.target)
        this.gameAction('wrong')
    }

    //正确
    onCorrectClick(e) {
        e.target.hasRight = true;
        addSelect(e.target)
        addRight(e.target)
        this.number += 1;
        this.changePic()
        ++this.selectNum;
        if (this.selectNum > this.maxAns) {
            this.gameOver = true;
            removeCountdown(this.view_middle)
            this.gameAction('success')
            
        }   
    }

    // 变换图片或者数字
    changePic(){
        this.numBox.text = String(this.number);
    }
    clearGame() {
        this.selectNum = 0;
        this.gameOver = false;
        this.initClick();
        this.scenes.clearGame && this.scenes.clearGame();
    }

    // 游戏状态
    gameAction(type) {
        let parmas = {
            type
        }
        if (type == 'success') {
            parmas.clear = () => {
                this.clearGame();
            }
            parmas.second = this.second - this.view_middle._second
            Laya.SoundManager.stopAllSound();
            setTimeout(() => {
                this.scenes.bg_panel && this.scenes.bg_panel.destroy();
                this.scenes.view_middle &&this.scenes.view_middle.destroy();
            }, 2500);
        }
        window.gameAction && window.gameAction(parmas); 
    }




}
import titlePlayer from '../../../../util/titlePlayer'
import choiceGame from '../../../../gameActions/choiceGame'
import {addBg} from '../../../../util/gameActions'

export default class GameAction extends Laya.View {
    constructor() { 
        super();
        GameAction.instance = this;
    }
    
    
    // 游戏状态
    gameAction(type) {
        window.gameAction && window.gameAction({type}); 
        console.log(`游戏${type}`);
    }

    onEnable() {
        //初始化舞台
        Laya.init(1334, 750, Laya.WebGL);
        Laya.stage.bgColor = "#fffcf0";
        Laya.stage.scaleMode = 'fixedheight'
        Laya.stage.alignH = "center";//设置水平居中对齐
        Laya.stage.alignV = "middle";
Laya.stage.screenMode = "horizontal";

        // 添加背景
        addBg(this.bg_panel,'https://img.qlchat.com/qlLive/activity/image/CWI3EBD3-HX1L-6LHI-1585987450065-VDXHNZGKS8UB.png');

        // 初始化游戏交互
        this.choiceGame = new choiceGame();
        this.choiceGame.init({
            scenes:this,
            boxArr:[this.wItem1,this.wItem2],
            AnsArr:[this.rightItem]
        })


         // 初始化题目播放器
        this.titlePlayer = new titlePlayer();
        this.titlePlayer.init({
            bgPanel:this.bg_panel,
            url:"https://media.qlchat.com/qlLive/activity/file/CD79S7YO-4SIN-1TWJ-1582267275540-SBNMXXA7RHNY.mp3"
        });

        
        // 游戏已加载
        this.gameAction('loaded')
    }

    onDisable() {
        
    }
}
// //////////////////////////目录设置-设置站点发布目录//////////////////////////
// 定义发布目录路径
fis.config.set('wwwPath', './public');
fis.config.set('prodPath', '/game-prod/laya');
fis.config.set('testPath', '/game-test/laya');
// 游戏项目目录
fis.config.set('gameName', 'test');

fis.set('project.ignore', ['node_modules/**', 'output/**', 'fis-conf.js', '**/_*.scss']);



// 默认部署方式-前端资源发布目录设置
fis.match('/release/web/(**)', {
    deploy: fis.plugin('local-deliver', {
        to: fis.config.get('wwwPath'),
    }),
});


fis.match('/release/web/(**)', {
    release: fis.config.get('gameName')+'/$1',
});

//测试打包上传
fis.media('cdn_test')
    .match('/release/web/(**).js', {
        preprocessor: function (content, file, options) {
            content = content.replace(/loadLib\(\"/g, 'loadLib("//res.qianliaowang.com' + fis.config.get('testPath') + '/' + fis.config.get('gameName') + '/');
            content = content.replace(/return URL\._basePath/g, 'return "//res.qianliaowang.com' + fis.config.get('testPath') + '/" + window._gameName + "/"');
            content = content.replace(/(loadLib\((.*?)laya(.*?)\.js(.*?),)/g, '');
            content = content.replace(/window.screenOrientation/g, 'window._gameName="' + fis.config.get('gameName') + '",window.screenOrientation');
            return content;
        },
    }).match('/release/**.{js,json,png,atlas}', {
        deploy: fis.plugin('upload-oss', {
            bucket: 'ql-static',
            region: 'oss-cn-hangzhou',
            to: fis.config.get('testPath') + '/'
        }),
        domain: '//res.qianliaowang.com'+ fis.config.get('testPath'),
    });


// 使用cdn线上部署-前端资源发布目录设置
fis.media('cdn_prod')
    .match('/release/web/(**).js', {
        preprocessor: function(content, file, options) {
            content = content.replace(/loadLib\(\"/g, 'loadLib("//res.qianliaowang.com' + fis.config.get('prodPath') + '/' + fis.config.get('gameName') + '/');
            content = content.replace(/return URL\._basePath/g, 'return "//res.qianliaowang.com' + fis.config.get('prodPath') + '/" + window._gameName + "/"');
            content = content.replace(/(loadLib\((.*?)laya(.*?)\.js(.*?),)/g, '');
            content = content.replace(/window.screenOrientation/g, 'window._gameName="' + fis.config.get('gameName') + '",window.screenOrientation');
            return content;
        },
    })
    .match('/release/**.{js,json,png,atlas}', {
        deploy: fis.plugin('upload-oss', {
            bucket: 'ql-static',
            region: 'oss-cn-hangzhou',
            to: fis.config.get('prodPath') + '/'
        }),
        domain: '//res.qianliaowang.com'+ fis.config.get('prodPath'),
    });


